// @ts-nocheck
import * as React from "react"
import { RenderTarget } from "framer"

/**
 * LFGAMidias — landing page para Framer (melhorias + fundo imersivo + notebook 3D + navbar que reaparece ao subir).
 * Como usar: Assets > Code > New Code File > cole este arquivo > arraste o
 * componente para a página (use-o como a página inteira, em largura total).
 * - WHATSAPP_NUMBER: dígitos com DDI+DDD (ex.: 5571999999999).
 * - LOGO_URL: envie a imagem em Assets e cole a URL aqui (opcional).
 * - O notebook 3D carrega o Three.js por https://esm.sh e só aparece no site publicado/preview;
 *   no canvas do Framer (ou se o carregamento falhar) a página mostra o mockup estático.
 */

const WHATSAPP_NUMBER = "SEU_NUMERO_AQUI"
const LOGO_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAACQCAYAAADnRuK4AAA0nElEQVR42u29eZhV1Zku/q619j77jDWcGihmmUREUUMlTlEhURxQ0CRUYrTbmJsUSVS6773evp3czgV++XXnmu4k/WiMgvEap6hVJgaZQQVEEaFKjQqKQAEFVUXNZx723mt99499TlEgQw1YdYBaz3Meqg6n9tl7rXe937i+DziHBxGxqqoqUVNTo/f2b2tqavSqqipBROxcnkPtXARNdXU137FjB2OM2QAkAKnrOkzTDADA28uWoUUp15e//OVKANi+ffvSUs7Nq+fOBQC4XK5oeXm5lb3mwoULtalTp9K8efMUY4zOpflk5xJwFi1aJBYvXmx3e8//4c6d17S1tFze1Nh4ucswrm48dEglUikupeSlpaU+AGhpaYkLIZTH41GjRo3i6ZT59vARZe8WB4PvTps2bTNjLNYdTIsWLZLnCpDYuQCcjRs3ipkzZ9pZ0LxbW3vVgX37ZnR0dPyXWCxW6nK5EI5EkE6loGkaOOcAANM07QzjaACglIJt2zAMA/n5+TDTafgDgZbi4uInx40du3H69OlbsmDasGGDNmPGjLMeSGc1gKqqqkRFRYXMACe48c03FzQ0NNzX0NBQrGkawuFw9qMW55wzxjgRHW9+ut5kjIGIlFJKAdABID8/H9K2MWLkyLaRI0c+OuPaax9mjHUcew9DADqDWIcxlvmRghs3blzw2d69DyTi8WBHZycYQGBMCs77rQQzxkgqJUEkiIgFg0EE/P6OSRMnPnLtESAxIsLZyEbsbGUdTdNQU1Nz2+69e5+qr68vCofDAGP26QBND8CkFRQUYOzYse0Txo27t7y8fLlt22clG501AGKM4fHHH9fnz59vEVHRK8uWPXXo4KHbWtpawRmzhBDaQJncjDGSUtpKKb20tBRjR49ePmfOnHsZY+1LlizRf/SjH1nHiMohAOWAyGIA1Pvvvz97x86dz+ytqwvatk2apmGwfDWMMbJtG5qusYkTJnZcPHXq30+bNm0lAE7OTZ/xKOJn+gMsXLiQM8aIiPjrGzYsWrt+/V/31tUFAdhCCDaYjj4iYkIIBoK9Z8+e4Oq1a/+6adOmRUTEGWO0kIgPAWiQwZNZKLF8xYq/7tmzZ2EsGuXkjJxxkmbuhSKRCP9k166Fq1at+isRCSxa1PUMQyJskMCzaNEi9tQzzyzraG+fHQqF0rquG7mqXzDGYFlWuqCgwCgpLV3593fdNZcxRgsXLsTixYvVEAMNAngee/zxZW2trbMjkYiVy+DJMBF0XTcikYjV3Nw8+/EnnlhGRGxxt2caYqABAM/ixYtBROx3jz66LJlKzY7FYpYQQj9TLBvGGKSUViAQ0H1e78of/+hHZywTnVEAyiifICL2+NInlkWjkdnxeNxijOln4u5VSln+QEDPD+StrPzhD+ZmjAEwxs4YEPEzCDyMMaaIiD37/PNnPHgAgHOux2MxKxyNzP7Tiy8u6/6MQwA6zeBZunSpRkS+VatXL2tpaZkdi8UszvkZC57uIIpFIlZTU9PsdevWLSMiX21trXamgEicCTc5YsQIff78+dY111zzswMHD1Y2Hz6c1nXddbZ4c7kQIh6PpxnnU8KRiHn1VVe9MWLECH3FihU5L8pyHuVVVVVi3rx5tG3btlve2rLlxXA47BrIsMQAKtZk27ZdWFBgXnvNNd+ZPn36KudtltOxs5wWYQsXLuSZ4KP7ox07XorFYj4hxFmZRkpETNM0EY3FfB99/PFLANyMMZnr5j3P5QmdMWMGJyLfs8/96aVDhw55iEjSWeD+P5mVSUTyQH2954WXXnqJiHyZOWBDAOrlqK2t1WbOnGlv2LTpwVQ6eauU0j5TdLZ+6hRCSmnH4/FbN2/e/ODMmTPt2tpabQhAvduJYvny5bKjo+OaPXv2PFhfX29pmnZOHAAgAJqmafv377d27d79YCQSuaa8vFwSUU5unpy8qalTp/L7779fXXzxxc80t7ScnwmOCpw7g2maRmnTdLccbh7/l7/85akLL7yQV1dX55zZmXMMlM3aW7169ZyGpqbrEomExDl4/AiAlkwk5KHGhuvWrl07p6KiQlZVVeXcJsqphenmiQ0+9cc/vhCPxymT03POoYeIIIRgsViMGpqaXiCi0Yyxzswc5cyE5BQDZTywqK6ufqCtvd3DGLPPZqurJ1YZALutrc3zyiuvPACAli5dmlObPmcWZ+HChby8vNxubGz0NDQ1LkgkEmCMaTjHB+dci8fjOFBfvyAUCgUrKytlLpn1OQOgqVOnMk3TaFtNzQvxeCKYiUgzDA0GItuWMvhSdfX9jDGVSyyUEzdCRIIxplpaWq5bsWrVnGQyKXVdF0PYySCIMS0SiUi/3/9PHR0dbwSDwbcyczboYY6cYKDq6moIIeidd99d3NjURC6Xi4Zg022DAYxzjnA47NtWU/OvROSqrq7OEXrMDfaRoVBoVvXLL6/dt3+/NAxDnIuW1ylYiGzbRnFRsXXvN78xMm/kyLZcsMgGnYGWLl3KAWDNunU3hSMR0nVdDYHn+C4OIYSdSqfEqxs23JeZu0FXQbTBnhTGmEVEwUceffTuSCQCwbl2GuFDmd2b/T4FIkXH+FuO9b84b9HnyJqxI9fqxgzH/s4ZY/yYa58uptcSiQQLR6MLiOgRxljHYLOQNsjsoxGReu211xbYUpaAMZv6dk+UyZW2iQhKKTDGdJ5xQiopIaWE2+0Wbo9HCM6RDa1xzsE4A8usMeccjPGjwJIFFZGCU5Qj+x51/W7bNpRSSKaSSCVTEEKAcec6SioQkeVcm4ExpmXA1VtgMQCWaZrBjW++uYCIfpFhcOuc04G6+TL0Z597rmHP3r3FTqrPKX0cWbBIKSUxxnTGGBQp5AXy4HK5YBgGopEoTNtKGi5XOi8QsIcNK+PhUPidpuamrT6fL61pWqIwPx8FRQUoLCiEoRsQuoDH64HXMKBpBoRwDEEpJWzbRiKdQDKRhLQk0uk0OiOdCLWH0NnZCdu2vfFk0igbNuyK/Pz8K1taWlQkEtXSVtpw6S5PIBBAKpWCZVmIRKPgzjOAiCwhBGOMiZ6AijFGtpRs8vnnt911553DM87WQWOhwWQgzhiTb2196/K29rY8xtgJI86Z0wpKKkWCc01KiUAgoPl8PiSTSXDOo0XBYKKtvX1JYX7+4RtuuJGXlZW+43Yb76VS6VHd5FGYMRZLx9Jfspm6cu/eOtnQcEh89uk+xBIJJGIxxJNJpBJpKCWhoDKKIgfnAm6vAZ/HA6/fD7/Xi6KiAkyZcpGcMGG80Ii/bviN94jIDyA/e+u6rh+yLOtLh1tarly7erXqCIXKJk2YML+9o8MrpQx4vV49Fo8jFo2Ccw6llO2UKmLHzQMiIsYZk83NzXk1778/E8D6jC4rzykGyqSq8leXL39tx86d15qmKdEtO6CLZZQiEGlutxuBQACJeDxVWloajsXjj914443t50+cuAXALgCFhmEc2r59+w/Xr1/vWrNmjZtrrvxZs276YXtbu9Hc2kbxeFxPp0zNMAyPz+eHaZqwbRtSyow4oi7RdHwdyHlx7vwrhICmaXC5XIjHY0in00m3Ydhev9caVlLCgsHC9I6dO58gaYfPP398au7cO8zLvnTpE2Y6PQpAJ4DJn3322VWr164tCvj9P25pbc33+XzuSDSKdCqVLUfTnZ2yILLy8vL0woKC337/3nv/25IlS/T58+db5wyAspRLRMMeW7KkvrGx0aXrOnV7X1m2zb0eDwsEAnDpeszn928cO3bsq9dcffVTAIoBtDz99NM/eOaZZwIuw5ipCXHVJ59+arg9Hm8sGgUpYML5FyGVTINIQQgNjDNwxiCVgpKyu05yXIX4JPf/OT2IC6ELzrtAmAVlQWEBQAr7930CLjistJWYMuWCtGXbW2zL2nD33XdH77nnnj8AKAXQtnnz5nv3HzgwJ5FIzDAtyx+NRpFMJqFpmswCiQEklWIlxcWt999331TGWOtgibFBAVBNTY1eXl5ubd68+R/e/9vfft3W1qY451rG18HdbjeKi4vBgJWXTJu27Ctf+crLAOjll1+e9+hjj44O+AI//OSTTwoUkTsajaIzFIK0bei6Dtu2bSEEXXrZFcjLK4RSUsuwWTfD7AhS+usyOBp0RNkpzb4vpbQ1TUNbWys+/NtWpusuzbIsCCEQLCyEPxCA4Dw1ZcqUUCyWeOL++39y8I477qgGwLZu3fatDz/621wCZre3tyMWi5FhGIoxJmzbtsrKyvTLLrvsv151xRX/mZ3TcwJA8+bNE1VVVfy5559feaD+4A1S2qZlWS5d11FUVJS4aOrUN6679trFAPa8+OKLFa+uWHFbw8GDMw41NPg72tsRDoehu1wgIlsIQUKILtPZskx23nnnY8zYCTBNs8es8sUyroLucuPAvl2or99LhuGGlFJlXowxppmmiYKCAgSDQYwZPTo2ctSojXPnzFk+b968KgCTNmza9L/379t3a9Phw0gkEuRyuSwhhGv8+PHr7vz2t2+tqKhQ1dXV8qwHUHfx9fvHHz/Y2NjIvF6vVlxcjNLi4r/cfvvtFQAC99xzzw8aGht/drD+YOGB+gOwbRucc1vTNMoc6zmqcJRz3tyGz5+HadO+cpSY6T2T9FyMdZ9IOsV1iQgf/u1dJJMJCCG6rsEYo8x5edu2baaU0jRNw9ixYzFm9JjO884b+8snnnjiCQDnv/7GGz//dNeuW8ORCBLxuD1q1Cj6UWXlKMZYy2CIsQG3wjIJ4taWLVu+k0qluN/vF0XB4Lq777rr//N4PJ98//vf/9l777//X5saGwvb2trAhbANw2C6rnOlVFe53eMvKjBm9ARwLmBZJjjnEJoGwXmXc1BlF61LKXauJ6UCkXJ21AnAdGTBOTRNgGeuS0QgOMkDnLEup2NG13L+jgi6y8Do0ePx6acfdrkIspsqcyZe13UdnHMiIlVXV0d7du8uLC4u/lVNbe1Pp1544S+fe+65v//Sl788tfrFF3/ewdisRCIha95773sAfpXxTFtnNYAeeughRUT6S9XVs10ul5g6deryim9+c05TY+PMt7ds2bN927bCaDwOTQjb6/MJItKOWEYnZg/btlFYWISCwmJIKeFyGbBtC9FIJ8LhEOKxKCwzDVs6dcaF0ODSXfD6/MjLL4Tfnwddd0Epx+l4vCGE6AJnqDOESKQT8XgMlmVCZq7rWGUGvL4A8vML4PM515XShmWlUVQ8DPn5hYhEQsiU3/vc9yilGABhGAYYYxSJRmXHxx8X1tfX/+qWW2/96Vevuvab/+f//P83vlRd/deDhw7N3bJlSyFjDLVnux8oQ7ESQL5t29eTNO/49rx5f6388Y9XPv3007fs278fhmFYbsPQlFLaiZjmRFGLsrLRjhMxGsLB+gY0NzciHov0SIx5fX6UlJRhxIgx8PkDGTdCFqCAIkI8FkFT40G0tjQhkYj3SCz6/XkoHTYCw4ePhuH2AADKho9GJNLZIzFJRIxzrrndbkokEvaa1asLP/v00zfuv//+VXd++9uzf/GLX9xeUFDwVGdn568KCgoGPOWVDQKA6JFHHikqKC6+8O/uvHPzDbNmrdy+ffstsVhMejweLqXs1T1l2ScQyMcll16OgwfrsH/fbpjpdI/1m+4AE0JDsKgYeXmFcGcWPJVKIhLpREd761Hs1JvrGoYb542bhFGjx0FKiQ/efwfpdBIZ3b/HQwhByWRS+f1+ceUVV6xas3r17Gefe3GmlOkP77nnnvazGkDH6pszZ85cVVNbe7Npmpau63rvGOfIkFJi7NgJiEYdhjjiiMQJVNsTg/FUbNWTz3zeAXkETCWlZbjk0suxf/9nOLB/L1yONdk7Fz7nsCzLcrlc+uVXXLH6tXXrbjmFLv/FhRMGIf7FichfWVm5qra29mbLsixN0/oMHiKCpmk4WL8PTY0HjwqA9nYuu1lFx331zW9ER123teUwPnhvK4KFJSfUgU41lFLQNE23LMva9u67N//kJz9ZlQmhDPgx6AFNGx0xYoS+cuVKe9y4cT975tnnftDc3Jw2DKNfZVo450in0jDNdB/YYeAH5xzxeAxcCAhNIJmMQ/C+LYPIlIUJRyIXFBcXW3/+8583DHRZGDaQ7JPx/wSvmzFj95tvvpkfCAR6rfMce/NSKaSSSZxZg0HTBAqDxYjFwuBMgPooeYQQFI1G1cwZM8NvvPH6lExYY8D6cgwYAzU1Nek1NTX077/+9T+tWL7iZsu2ZH+/nzEGy7TQV/E3mEMpBZAC51qfwdPdsk0mk/5UMtn4xhtvbG1qatJra2sHZFL4QLHP0qVLLQC+z3bteqC5+XBXD65+XheKzsjyygCcJDSA+q32ulwu3tbaig0bN91CRJ7Ozs4Bq7M4IADKKqDRaNS9detWQ9N1nAl5z92V5y/ECafrEELLeLH7t46KCB0d7dcBkNXV1XKgYoADAqAlS5ZoAPDZnj0/lFL6pJTWaejTdaoPOADgHIwLcCHAhQauOS+h6RC6DqG7+vnSITS967pcaOBCgPFsSis7YWjEcLlhGG4nht+PBVdKgXMuW1pb5ep162YAwLx58/hZA6Ds2LNnjzuVSjEuRJ8Bk82/sW3bSe7KLFAWIA4wXNCyC6zpEF0Lq4FzJxzBunKf2UnN9pOZ9c6Lg3Hedd3s9wjt+PeSvUcAKAwWw+32wLJMKKWOMvd7OTdMKaU8brdHWdbXAOD6668fkLUd0FBGe2urzC58T0QYO5I3nNllDLquw+12w+32QHdpCOSX4JMdH2ZiUafyow2E2KQTb4As6ACAFG771nzs/PAtpM0YAIFUMgnbsiCdQwFdr1PNVcbqQjqdpqampuhArumAAqikpERomnCi3ieZGMaYEyFXCpwxGIYBr9cLj9cLwzDAMzs+HgtjyoXTkZdfhjdffwWGx9cV1MzVIbhAOhnHFV+9CZMu+BLqdr+HgvwCGG7n3tPpNJKJBBKJBNLpdPaESSbyTyfdaIZhsOHDhwfOWgCdd955KZfLTSRPARwpoes68n1++AL+LtB0ZyMnhQJImyncesf3sX/vTtTv3wWXxwdSEv11Th5hs4zoBIH64S5w9DEHPOMnTsXsO+5FKpUAiEFJ2WVNut1ueDweFBQWIp1OIxaNIhaPw7aszBEkDnz+2YhzzpPJVFrX9TcA4LXXXjt7zPj58+fbAMDz8p4gUnGhCf14XG/bNoQQKC4pwajRo1FcWgKP2w0AXTnGx+oltmVD012498c/x+QLvwQzGc/mKPdKl3B2uaObmakkzFSi278JWKlkBlx9uK4QkErBTMYx5aJyfG/+v0BoOpSSABTQLaCazacGAI/bjZLSUowePRpFxcXOqQ37hAwrPB63uX///g0AUF1drc4aBsrK6OmTJ6cmT56c3L17t797EDH7b0FhIQoLC6HrehcTnSjhPZt9rKQN20rDMDy498cLsem1v+DN119BPBYB4xxCd4F3LRAd2bysK3sZRAq2bYGkhMvw4IKp5Rh93vkoKCwGAIQ6WnHwwGfYu2cHzFQCTAhomp6JpGfcgN1SP7JXVqRgWyZIKfgD+bhu9l249ut3QCkJy0pD11wwTfNzqlv2WRU5rCeEQFFREQKBAMKdnQhHIkd9jjEG0zQx7eKLk5WVld758+eHs3N+VgCIMUbTp0/XAcRTyeSTeXl5/2yaps05153kLxdKSkrg9fkgleyysE45AZzDNBNAJp1VkcINt9yJS6d/Fdu2rMfHH7yD1tamriSyk4mswmAJpl58Ob585Q0YPnIchKahe0KQtG00HtqLbe+8hk8+2obOztZTijQuNJQOG4WLL70SX7lqFopLRiCRiHUxmVQSppnKPOfJ9RvbtqFpGkqGDYPP70draytM04QQArZt28FgUOecPw8gUllZqTPGrLOGgQCgsrISjDFat2ZN6L4FC1C3bx90TYPP50NpaSmEpvUcOBk24YwhmYhBSrtL/MRjYeQXlODWO/4LZtzwTTQeqkP9/t1oaT6IWLTTOW8Fgsvlhj+Qj+KSkRh93vkYOXo88vKLYFmmo5scs6CMMQwfOQ7fvPM+RG7+DhoO7sXBA7vR1tKAWCzk5B8xBrfbA3+gAKXDRmPMeedjxKjx8PnzkU4nEY9Huu4TAKRtIZWMgjHRI1GYBZLH68WIUSPRcrgFyUQcRMQNwzC//vWvr2aM0bx5887qYGrxrJtu2vXaunXB4tJSKi0tZSAnV7l3lJtNoi/A3IoF0F0GSMmMSCIQKXDhpJcK4bCJlE7cjDIMIITmnBOTEqaZhpRWl2/o+M+gMsUv9cx1BVT2ulKBMXT5gpwkeQumaUJJ+6jrEgica0glo3i16mGk04kMiKjHKkHW/9XS0kLtra3s+utvaFu7ds1wxlhP/BlnniMxK8YYY21jR49+eMSIESguLraz6kPv5TVBcIFUMopEPAzOeDeJk1GIiZBOJhCPhRGPR5BOO2fTbcuCmU4hEY8iFgsjmYyDSJ5SQWbMcR8QSSSTccRiYSTiUZjpNGzbgmVZSKeTSMQjiMfCSCeTANHnr0vOvcejIaRS8V6Bp4uNMj8XFxfbZcOHY/Lk8x8FQJWVlToGMKlsMFJaEQqFCr85b97ugwcPFupOXKxP98E4g5lK4Ws33Y2Jk6cjnUo4Zm6OD1IKbo8POz/agjdfexFuj69PGQWMMbIsC+POG9e5ZvWqSYNR7mVAZ5sxRpWVlVphYWHHxRdf/LDX62VKKbs/+Fek0HL4wFG78kwYRISWwwf6dQ2llO3z+dgl0y55mHPekVGeB3QaButgIYiocO4dd+z++OOPCzJAYn0AJCzLRHHJSNz6jfv6lVeDgd1JIKXwavXDCIdaoWl6X/KiKR6P06WXXhr6y8svT8oUIcdAA4gP/NwxWrJkicY575g7d+4jI0eO5Ol02u6Lz8LJh9bR0X4YnR2H+7QQA7+BFDTNhbbWQ30GD2MMqVTKHjN6NP/GN77xCOe8Y8mSJdpgFFcYFIWhsrLSJiLx/e9979/Hjx+/Wdd1HX2sb+OcUEijft9OCKEfz82fYwBy4mH1dR9D2lZfnX3S5XLpEydN2nz3d7/77/Stb4nKyspBCQIOCoAYY1RVVQXGWPy//eOD/2vs2LHxRCKhOOe9Xn2VYaF9ez90LJocV6KFcILAB+p2QNNdUKpPokuNGzc+/k8PPvi/GGPxqnnzMFgVygZttisqKmRNTY1+ySVTN8+ePfuhcePG630SZUTQdRc62ptwcP9OuAx3v4KeX7T1pbvcqN/3EcKhtkxeUO/M93Q6bU+YOFGfM+e2hyZPnry5pqZGz7QFxTkFIACoq6tTROS778c/fnTatGmrFJEGol5PhuNY49j50RbIjDc7J3VnzmGZKez86B1wIXotbjMtP7XLLr10VeUPfvAoEfnq6uoGdbcMGoCyO2fDhg2/XPbqqz/9z9/8evbNN91EiWRScM5VbwGkG240NexF3e6/wTC8OcdCpCQMw4s9u2rR2lzveM57ASDOuUomk+LW2bfSf/zqV7NfWbbsp5vefPOXWSYfrOcalCKbmer0VkdHx1dffOmlH3aGQmL16tVrL7zwwutaW1s3b9++HR6PR/Wq1RMRhNDw/vb1GDNuCpgQgFInzEceaJ8PFxrisTA+qHkDmt6748ycMRWPx3HFFVfin//nz66+cdYN19e+//4/FBcXyUgkUpWXlzdovTP4IEwmW7p0KSci36rVq/8tFA67U+m0ONzSsn7MmDHtX7788uvHj5/AM9XFqDeLpOkudLQ14oPtr8EwvDlz5IeI4HJ58N67a7pMd/S88BWlTROTJk1iX58543qPR2cNTU3r06YpOjtD7uUrVv0bEfkyc8rOegDV1tZq8+fPtzZs2PBgJBq9JpFIWIJz1djYiIcfeeSpB//xH1+/8IKptxUVFTHTsmRvLLNsiOCjD95E/b4dMNy+TNLW4A2lJNweH+r2fICdH2+B2+3tcdiCMaZM05QlJSVs6pQpt/zwhz98fdmry9+sr6+HJgTi8bgViYav2bR584Pz58+3BqO780AXVxDl5eVWR0fHV/fU1T3Y2Nho6bquAdDS6bRMpFKX//6xx9Y+/PBvVoyfMGFOaUmJFovFzF6b94xh8+tViEU6oOsGaJCYiJSCy+VGqKMZb2942fFT9cJcT6fTVFZWpl1w/vm3/fa3v13z8COPrN23fx/nnEsi4rquaw0NDdbuQezuzAcQPKy6uhpE5Fuzft2/tbe3+zVN66JdzrlIJZNWPJmc9Ycnn1z9wnPPrfiHBx5YduGUKUYqlaKeirOsdzoW68Qba551coWENuBKtVIKQtNhmkm8vuYZJJMx5xBhz06jUNo0aXhZmfiHBxYse/qPf1y59A9/WJ0yzVnkXEBk51TXddbe3uZ/dcWKXzDG1EC3gRowANXW1mrz5s1TW7du/R/hUOiaeDxusWMyqTjnejQSscKRyE1/ePLJFZWVlbfPue22RR6PB5lqpqqnO98wvDjctA+vr34ajAhC0wbsDL1SClqmrN36FX9EW8shuFzuHjEhY0xZlkWFBQWYfP75t93z9393+9L/+4fVkWjkpmgk8rk5A6Alk0nZ0NBw3cuvvDJn3rx5aiC7O/MvknGyr6qqKlFeXi4BeGpq33ugsfGw1HVdO16nHCGEHgqFrFA4PPs3v/nP1T/60Y8WX3n55XOKi4vJNE3WU3GmlITb7UX9/p1Yu+L/wrYtuAzjC9eJlHLyqs10AmuXP4HGhj091ns452SaJisbXsYuveyyOU8++eSKh3/3u9WdHaGbwqGwJYTQjzdnnAuWTCZVc3PzCwA8O3bsoIEC0WnX2quqqsSOHSVs8eKZ9rFf9dzzLyyr21c3R0opgRPLaqdsnbTy8/P0vPz89fN/8INZP//5ohu3vvvOq5/u2qUFAgGnFGoPvLicC6RSCRSXjMCMWXejuHQUUskYTnfSuXM9DrfHh5amfdiw7k8IdTY71mAmU/LE98vAAIpEozRlygX2tV+9bs6//MtP1/7+sSVrY4nYrGgkclzwHDMk45xPmjhx+V133jk32+mqsrJGu/76OvVFeavZaZxAntFTKPO7P8NwHIB8v2bD197Z/uFfO0MhxU9RGJAyU6qUtAKBPF1wWnffff99zsGDn3zj33/9yNOrV68WhsvFe+pL4VzANFNwudz4ytW3YvLUKzJnv07vkNLGJx9twfZ3VjmMp/eM8RhjMC1Lzb7lFvnP/3PBPcOGnf+XR373H68S2KxoJGpxLnQCnXKxlCJVWFjIv3r1JXOnTbtuQ16eEY1GzWPXSOUcgObNqxLV1RXS5WJYs2bvja+9deBaj0v+IBxNulOmDV0ItHe057UcbiWhcVAvvpcUlKYJHsgrSJQNGxZWKj1sw4aN/MgR6R5bNU6pXdvEqNGT4Q8UQCl5WljIcRQKREPtaDi0G7rLDadvxqkbT2crwLp0HTNnzlCM6c2HDzfnR6Mhr20rxXjP1QwGkJQKxSXFbOL4cZGGxrYtw8uKtt5+y6RtV1wxZrVpUtda5QyAFm7YoC2eOdN+Z/tnN/zx2U//+649bTfG4kB7e0fXOXBn97CuJm89Xpgs8RMUgXi2cZzf7++Dh9m5BzAGy0x9IQo15wK6ywCIMsltrDcoRCwWgxDCKULOmGIA781Vsp+1pQ0pFdxuDwJ5PuT7GS6+sGzd/ZUX/8eECSPXb9iwQZs5c6Y96ACqqqoSFRUV8rEnNt6y7o3G5bt2h7iUSSUEV5p2bOE/Yv1J1WEAwQEkk/1UhB0JeroPLmS2Sp99TsypqJ85/Uj9WBvGnKZ8SpGSksi2pRCal102rUR97zuTb5s1a9qqqioSFRX9D31ofQcPiYqKRVRTs/eaf/3NtmUffNQEv1fYTh8L8N7mufRgd3WTV/3TX3pb/rfn+79/9yYV9XtTZ54va2AIzhkMQwdg2m9vPcB1XSzraOn4WrB00dunI37WD1NvKt/16f0qSVc+89GOzvFugyQNcg/WoXFyCWu4uGxoSmqNzR3jt7/zk6c+/vhCvnNndb92Eu8b+ziK2Otv7Lil/lDyOmknJYgNgSfHh9NWKiF37Yld98mewzdVV1fIqqr+hT76BKDqaoe5/rx8V3kyxYkLLglDvd5zfRARdJ2rjpCklas/nQEAnZ21fEAB5MS0dthEZGi6uCocjjFNMDG0PGeIHOMM6bTF1m/YEweApbX96/HTR/QtVgCMsrLAV9OpJHhvO4YMjUGmIoZk2nLWrJ89onq98M4Z9yU65zyy/vW9vy0oKITdr9OlQ2NgwePYeYUBj+NvmD7AAAKA6ZWOPC2/bLjtMjScbpN9aHxxw7YV/D4DN10/2QcAldOnDwKAMrCdc8sUM+DXSdpDADpjhBfjnDEzffHFw98AgMLC6f1yybO+3gfAKBJpKP7W3Wv21R+K+jPF59nQGuWyGQ8yTWIXTC4M//WFe4YxxtLZtRxQBso6hAOBEanx4wpSlq1y9izW0DhKf4VlK0yaUNi19v09Cc77eCM0ffoSHUC88XDkiYA/ADmkSOe+/CICY0JKq8ldX/d2ebYB4CCY8UBl5XQwxmjmNRMTfr8BKYf0oNwHEJjhAlx61Fi/aecvGGPU3xzqfqDPcSBcNMXtcRkEpc7syeXccbJx7mSKdH91/78zVnwBUJLB7yWhi4Ts6Ahft3r1ujkVFRWyP+mvWt+QTIwxZhFR8Nnnn52fSjRDcENjjEBnEBE5AGGwJSGdVJDKKV4phAMWAkCKICVBESA4g2FwcJ4t5HlmIUgSEAhIeDycRaJxau9ofYGIRmeKU/WpNF6fALR06VINgLV2/esPRCMdRcECsto6oGtnFOMwmJaCmZbIy9MwabwfY8e4UVriQp5fQNOdlgKWrRCJSBxuNVFfn8SBg2nE4jYMg0PX+BnlAyMCggUKjCnOAKu5pcWzYdOmBwAsXrp0qQ7A+sIBlEGqTUTBx5c8saCzs5NKgh7ts7ozh3UAIBa3MXyYC1dfUYBpFwVQXOSCJhgU4Sh2YQzgzGndbdkKra0WPvgogre2htDWbsPndSqsnglsxBhQWCBBCuCCa+FwGHv27FlARI/0lYV6LfsyXYHl9OnT/+lwc/PNlpW2FTGxr17PeR2BMUBKwLYJs74WxN99ZwQunOyDrnOYFsE0FSxLwbYBKR3RZVkEy1IwLQWlgIBf4ILJfnzp0jxYlkLdviQEZzgTooGaAC66IAWXi6CIMQbYjDF/R3t78k9/+tPGvnR81vrKPo8+9tiCSCRCmuCa36fgcROSqdxVNLPg4Rz43l3DUX5ZPuIJiWhMOgoyQ1c/r6ObujgpsNn3LJuQNm143AJ3VwzHeWPcePHlZnBk9CbKzWe3JVCQp+DzEKTM9CxjTAuHw1R/6FCfWahXy53RfejPf/7zA+lUKpjRP5nbUMjPU5CKIRf9iYw5C0tEuPfuESi/LB+hiA2lACGO3HO2E2K2rVT2Zdt2VxI+Y87fSEmIRG1cc1UhvltRBss+9QmMwRxSMuQHFHT9KHHLGGN2MpkMvrJs2QMAKLPGp5+BurPP7x59dEEkGiXGmEYEcOHI1kONWo6yD0M8YWPu7BJcdkkAobANTRxZ7EzPUfh8Png8HrhcLufcGAFSSVimiUQyiWQymTkJyruAFA7buPryQhw8lMJrGzvg9+VocJmAYIH9uQ3OGNPCkQg1Njb2iYW0XrKPVf3nPz+QNs1gRmPXs9p9UYHMST2AMcA0FUaPdGPmNUHEYhKCHw0ev9+PYGEQhts4asK7HCgACgGkUil0tHcgnoh3HUzknCGRtDHr60X428cxRCIS3Rv95IzVKYCCAoXjYJsxwEqn01kW6pVFpvWWfR597LEFkWiUODuSA60kkBeQx9Jj7gDIUri8PB9er0AsZoNnAKSUQnFxMQqDQUCprk6IR/e1ONLvzO12Y8TIEWhra0NnZ2cXE9kWoSBfx5cvC2DV+nboupZT9aqlBNwuQr5f4XgnolhGFzrc1NRrFuK9YB9atnz5A+l0OsiAbEcYRzlVDD6vgt+jIHOjqlw3hgE8BsfECV5Y1hE9RUmFwsJCBIPBTMvJE3dM7moAlwFZSUkJ8vLyujr0OP3ECOdP8kHXWE6Bx9H/GPx+BY9HOgr0cR+R2clUKrhy5cpe6UJab9jn8aVLF4TDYeKca8c6qFwuQl5AoTMsAEE5M3m2TcgLCBTka11WGBFBd+koLCzsai/Zux0tURQMIp6IgzLdpG1JCBbq8HgELIvAGXLmmIGUQGG+I1pP9LhZFmo43DtdiPeUfda//voDyWQy2K0f1ecWK1ggc9KM1TSG7q3qFRG8Xi80re+iRtN1eD3eoxRmTThhkFycg2CBPPV+Y8xOJJLBjHe6Ryyk9ZB9Sp5+5pkFnZ2dEEIc929IAcFCCZ5L5zPIAXbaJNgWwXAd0Yu792zt9WUzOpFLdx2ZfQCmSbBscsRGTm0goCBf4lQnwhljWkd7Bw4ePLiAiH7PGGs7FQudlIGyRRu3b99+Vywez1pex9VwpALyAgqGK3ci8wTH1I7FJdo7LGjaEXagTNfe/qhr2SqwRICmcbS0pZFMyqPYbtDFlwI8boWAT0HSKR+YAbBisViwtrb2ru4Y6BOA6urqlBCC3n333ZtDoRCEEPzEXl4Gr1vB71W5Up65SwE20wo7P41D11gXuFOpVCabk/XpmkoppNPprhIzjBN2fBKHkrmlQCvJkBdQcBuOBXaqp9WE4J2dIWzdtu1mwTmdqhI+PwlNi4qKCrlly5Zrwdgs0zQlThE70zRCQYGEVLljhhER3G6Obe+F0d5pQdedcEUiEUc6lQTnvFeiLOtITGYciwCDy8VxuDmN9/4WgdstckoHUspx8vZUtSBApNMpCWDWtu3br62oqDhp5Vd+Ih7LVFR17a+v/0U4EqGeVvQK5kvk0siKl/YOGytWt8Lj5iBymKiltdXxQouegShTwxHSttHW2tr1N7oGLFvZhnhC5ZwSzVhmTXpxT0IIhEIhqtu//xdE5DpZ1qJ2fNlOjDEmGxoaChsbG69Ip9PIlOQ9hU4AFBaonNIBnF1I8HkFtrwbRkmJC7NvLEY0KpFIptDY2IDS0mEwDKPLkdilI3XzATHGIIRAKplCc/NhJFMmNE3A5+X4y6steP9vEfhyLIxBBOg6kJ8v0UtvBU+n02hoaLiisbExr6Ki4oTK9HFpZePGjQIANm3efJ9lWUIIYZ+qjH5WDwr4JTwGQarcA5HHw/Hqylb8ZXkL3AaD160hHk+hvv4g2lpbYZpOPUEuBDRNg6ZpEBnmNU0TLS0tqD94EKm0CZ9Pg6YRXnj5MNa83g6fV+QUeFhGgfZ5JfzeXge6mRDCtixLvP322/d1x8QpGSgDFElEJUuffHJBLBYTvIfySynAbSjk+SUSrRpEDoY23G6O1WvbUV+fxJxbSnHeGA9sqdDR2YmOzhBcLgMulw5d00EAbNuCaVowzTQAgsejgXOG3XvjWLayBXv2puD1idwLoHZToF06wbR6nSmhRaNRFo3FFhDR7wEcl4W045nu5eXl9tZt2+6yLDNIRF1B0x59ayYy39ice5H5LJh9PoFPdiWwd189Lpvmx1fK8zF2tAceDwfIgm2ZME2npiJjjiNS0wTiCcea27o9hA8/jkFKgt8vcvZEipPCKvtqETMislLpdLC2tvau8vLy/8y0lbJOCqC6ujrFGKMPP/ro5lDniU33k/leCgtkLqfGdIkzpYB3toWx/b0Ihg1zYewoD0YMN1BYoDnWFAiplEJHh43GphQOHEyhpdWCUo5lp+ssp48zcZ5JYe3jLQoheGdnJ3bs2HkzEf2+urpaHltZUjvWdGeMyebm5lnLli+flUqlpK5pvYpsSQkU5EnoWm73v836g3w+J5zR0mKhoSENgpMDfSRiT1AZz7OuMxgGA2NOMn0uH2XKxifzA6o/+ig3TRPtnR1fa2hoCFRUVLQfK8aOYpdMzymxrabmpmg0RlzwXkn2rCLt8yn4PPKMOCumFGWsFQafT4Pfp8Hr5TAMByxeL4ffp8HnFZlIO3L+JEY2fdfvV/C6FVTfM0UZ59y2bZtt27btfiISxyrTvLvyPH/+fAsAazrc9N1QKMQEF1pfkG+4CHl5dKLUgZzdsQ6rOMzipMA6TJV9/0w6ByYlQ8FpyNFijIlYLCbCkcj9ANjMmTOPssj5sWDaunXrzEg4EuScyb52wOMMKCywz6yDd2fRyC5a8DToohmRJTs7O/NqampmHosb3l18AcCnn312M+dcB6D6s5uLCuQZfRT4TB4KgNAcBfo0NSdSYMz16aef3twdK11KdLejyiW/+/3v7w6FQjg2aaxX9ElAION/GCpeNjgGgsdQCPgzDt1+shBnTAuFQjBcrruJ6JeMsdasMs2zvp+Mt/EuACU4SdpGTxQ4JRl8HgWfT0FKYKh00MAq0EoyBAIKHkM6CnR/9cOMT4gIJW++9dZRaR4cAB566CFFREZza+stoXAYvJ+9kByrhpAfyK3I/LnEQAV5pzcmKYTgneFOtDQ330JExkMPPaQAQMsqSQD8Zjo9I5VMwtWLXlwnU6SDhRJ1B4YWdDC06KKC01vvizHGU8kUTNOcAcBdXV0dJqIjJ7l2795NbR0d8f7kCR+lBynHCuBDJcgH2B8BaIKQn3d6/XBOM2MNbe3t8fb29s87Ejs6OiBtm5+uWodKAgE/wXMWFJ86k4ZUgNdL8PvVaffDMcZgWxbv6OjA5wAUDAad9MzTpMhJxeD1SOTnyTPKoXimK9BSMgQLJNzG6beACQA4P4oOugA0adIk+LxeTur0VVzlHBg/1sypHOlzQf+ZONY87cdCGGOQto38vDzfpEmTjuuJpqKiooQ8TfLGOVLMMG6MiTGjLCRTDGLIsfiFDcGBZIpj4nkmRo6w+pL/cyodSBmGASXlawBSCxcu5Iwxp9PykiVLdAAxTdOeDxYWkpTy9KjwmVjSVeVJlJXaSKRYV+HKoXH6xBZjQCLJMHqEiS9fmoRts9OeTqOIZCAQoLz8/HedAuWOE5pl0CUYY7Kurm7W6jVr1jYdPiw1TROnB7mAEI5Sve0DD/bsdw7jaYKGQh2nwd9j2U5hqwsmmvjSxcmuOT/d4suyLFlWViZm33bb7HGjR6/KYoZnPiCrqqrEhAkT1nm93k1ut5tnjjCfJsXOgeq1V8Yx+/oYJp5nweOhISbq57x6PYTJE0zcdkMMV5XHM5kDX8jX2X6/X+QFApvGjxmzqqqqqqvXKusm4wRjTH24c+e1b2/evPHQoUOWy+XST1elCU0QDrdqiMadwk3hqEBHSCAaE7CsIUD0Zug6kOeXKCq0EQgoMAD5eQolRbYjvk6z8SWltIuKitIzr7vulksuueQtIuJZAGndaEpWVVWJ6ZdcsmnVmjXLE4nEbeFQyBKa1i8QEQG6RvhgpwcffWJAKScpUghA8CEW6suwLKCtQ6C5VcuwO4MmCJdelMTUyWlYp0mBZozBtm2zrKzMKCkp+ddLLrlkc01Njc4Ys45nhWHevHnq9ttvF9d/7WvfGFZautIfCOhSSquvZn02Jna4RcdHOw24dILH7RTk1LUhHai/LhJdJ3g8zpwKQfjgYw/aOrXTUuiLMQYppRXIyzPy8/JWzvvmN/9jw4YN2vTp049SbbRj/oiISDHnh7nPPv/8stbW1tnt7e2KH+NA6imANI1wqMmFtCnB2JBX+osEVCrNcPgwQ1G+I8r6w0JKKV5UVKSXlZWt/O53vjOXMSfB8NhjPcf9ioULF3IAWLRoEd+0aVP1zk8+masyibWslwByGYRPdhuo+cADw0VDWYpfoFJtWgxXlicwYawJ0+wbgCizcIxzuujCi5Zde+1X5y1atEgBwOLFiz+3/dlJHEeMMcaEEOrQoUOzGWNXRyIRdbKD9icaKRNob9f62VhoaJyaNoCSEhsurT9AZDIvL48T8bdHjRq+UkrJyQHDcbf+/wNZ2NYONAXikwAAAABJRU5ErkJggg=="
const waConfigured = /^\d{10,15}$/.test(WHATSAPP_NUMBER)
const waBase = waConfigured ? `https://wa.me/${WHATSAPP_NUMBER}` : "#contato"

const C = {
    blue: "#2B3A8C",
    lavender: "#7A85BF",
    slate: "#818DA6",
    paper: "#F2F2F2",
    ink: "#0D0D0D",
    white: "#FFFFFF",
}

const projects = [
    { n: "01", name: "Alva", type: "Beleza & autocuidado", theme: "beauty" },
    { n: "02", name: "Norte Studio", type: "Arquitetura & interiores", theme: "architecture" },
    { n: "03", name: "Vértice", type: "Consultoria empresarial", theme: "business" },
]

/* ---- Notebook 3D (Three.js): o site é "construído" na tela conforme a página rola ---- */
function startScene(T, root, onFail) {
  var W = window, D = document, stopped = false, rafId = 0, cv = null, dock = null, renderer = null, rsH = null;
  function cleanup() {
    stopped = true; cancelAnimationFrame(rafId);
    if (rsH) W.removeEventListener("resize", rsH);
    if (cv && cv.parentNode) cv.parentNode.removeChild(cv);
    if (dock && dock.parentNode) dock.parentNode.removeChild(dock);
    if (renderer) renderer.dispose();
  }
  try {
    cv = D.createElement("canvas");
    cv.style.cssText = "position:fixed;left:0;top:0;width:100%;height:100%;z-index:3;pointer-events:none";
    dock = D.createElement("div"); dock.className = "lfga-dock";
    D.body.appendChild(dock); D.body.appendChild(cv);
    var r = new T.WebGLRenderer({ canvas: cv, alpha: true, antialias: true });
    renderer = r; r.setPixelRatio(Math.min(W.devicePixelRatio || 1, 2));
    var sc = new T.Scene(), cam = new T.PerspectiveCamera(32, 1, 0.1, 100);
    cam.position.set(0, 1.2, 11); cam.lookAt(0, 0, 0);
    sc.add(new T.AmbientLight(0xffffff, 0.8));
    var dl = new T.DirectionalLight(0xffffff, 0.9); dl.position.set(4, 6, 5); sc.add(dl);
    var pl = new T.PointLight(0x7a85bf, 0.9, 30); pl.position.set(-5, 2, 4); sc.add(pl);

    var rm = W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches;
    function cl(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
    function ss(v) { v = cl(v); return v * v * (3 - 2 * v); }

    /* ---------- tela: do código ao portfólio publicado ---------- */
    var SW = 1024, SH = 640, CH = 44, VH = SH - CH, PH = 1380;
    var c2 = D.createElement("canvas"); c2.width = SW; c2.height = SH;
    var g = c2.getContext("2d");
    var tex = new T.CanvasTexture(c2);
    tex.minFilter = T.LinearFilter; tex.generateMipmaps = false;
    var F = "Manrope,'DM Sans',Arial,sans-serif", MONO = "Consolas,Menlo,'Courier New',monospace";
    var BL = "#2B3A8C", INK = "#0D0D0D", WF = "#b4bacf", GR = "#626875";
    function rr(x, y, w, h, q, f, st) {
      g.beginPath(); g.moveTo(x + q, y); g.arcTo(x + w, y, x + w, y + h, q); g.arcTo(x + w, y + h, x, y + h, q);
      g.arcTo(x, y + h, x, y, q); g.arcTo(x, y, x + w, y, q); g.closePath();
      if (f) { g.fillStyle = f; g.fill(); }
      if (st) { g.strokeStyle = st; g.lineWidth = 2; g.stroke(); }
    }
    function circ(x, y, r, f, st) {
      g.beginPath(); g.arc(x, y, r, 0, 7);
      if (f) { g.fillStyle = f; g.fill(); }
      if (st) { g.strokeStyle = st; g.lineWidth = 2; g.stroke(); }
    }
    function tx(s, x, y, sz, col, wt, fam) { g.font = (wt || 700) + " " + sz + "px " + (fam || F); g.fillStyle = col; g.fillText(s, x, y); }
    function wb(x, y, w, h) { rr(x, y, w, h, Math.min(4, h / 2), "#e1e4ef"); }
    function xbox(x, y, w, h) {
      g.setLineDash([7, 5]); rr(x, y, w, h, 6, null, WF);
      g.beginPath(); g.moveTo(x, y); g.lineTo(x + w, y + h); g.moveTo(x + w, y); g.lineTo(x, y + h);
      g.strokeStyle = WF; g.lineWidth = 1.5; g.stroke(); g.setLineDash([]);
    }
    var CARDS = [["Alva", "Beleza & autocuidado", "#E9E5F2", "#cfc6e3", "Cuidado que", "começa em você."],
      ["Norte Studio", "Arquitetura & interiores", "#E8E7E2", "#c4c0b3", "Espaços com", "intenção."],
      ["Vértice", "Consultoria empresarial", "#E6EAF4", "#8d97d1", "Clareza para", "ir mais longe."]];
    function cardEl(i, w, f) {
      var x = 48 + i * 312, c = CARDS[i];
      return { w: w, f: f, x: x - 4, y: 636, W: 300, h: 232,
        wf: function () { xbox(x, 640, 292, 170); wb(x, 826, 140, 12); wb(x, 848, 100, 8); },
        fn: function () {
          rr(x, 640, 292, 170, 6, c[2]); rr(x + 12, 652, 268, 16, 3, "#fff"); rr(x + 12, 668, 268, 130, 2, "rgba(255,255,255,.7)");
          tx(c[0].toUpperCase(), x + 26, 692, 11, INK, 800); tx(c[4], x + 26, 730, 20, INK); tx(c[5], x + 26, 754, 20, INK);
          rr(x + 26, 772, 58, 16, 3, c[3]); circ(x + 244, 800, 46, c[3]);
          tx(c[0], x, 838, 19, INK, 800); tx(c[1], x, 858, 12, "#747986", 500);
        } };
    }
    var els = [
      { w: 0.29, f: 0.52, x: 0, y: 0, W: SW, h: 66,
        wf: function () { rr(48, 16, 32, 32, 8, null, WF); wb(94, 26, 90, 12); for (var i = 0; i < 3; i++) wb(560 + i * 90, 28, 60, 8); rr(860, 14, 116, 36, 7, null, WF); },
        fn: function () { rr(48, 16, 32, 32, 9, BL); tx("LF", 54, 38, 14, "#fff", 800); tx("Luiz Felipe", 92, 38, 18, INK, 800);
          tx("Projetos", 560, 37, 14, "#555b68", 500); tx("Sobre", 648, 37, 14, "#555b68", 500); tx("Contato", 722, 37, 14, "#555b68", 500);
          rr(850, 14, 126, 36, 7, null, BL); tx("Vamos conversar", 866, 37, 13, BL); } },
      { w: 0.31, f: 0.54, x: 0, y: 74, W: 600, h: 320,
        wf: function () { wb(48, 100, 140, 10); wb(48, 140, 430, 26); wb(48, 182, 360, 26); wb(48, 236, 420, 10); wb(48, 258, 330, 10); rr(48, 312, 196, 48, 6, null, WF); },
        fn: function () { tx("PORTFÓLIO 2026", 48, 110, 11, "#646a77"); tx("Desenvolvedor com", 48, 172, 52, INK); tx("olhar de designer.", 48, 230, 52, BL);
          tx("Sites e landing pages que unem código e design.", 48, 276, 17, GR, 400); rr(48, 312, 196, 48, 6, BL); tx("Ver projetos  ↗", 74, 342, 14, "#fff"); } },
      { w: 0.33, f: 0.57, x: 600, y: 74, W: SW - 600, h: 330,
        wf: function () { xbox(620, 96, 356, 284); },
        fn: function () { rr(620, 96, 356, 284, 16, "#eef0f9"); circ(798, 198, 62, "#c9cfee"); tx("LF", 770, 214, 40, BL, 800);
          rr(668, 286, 260, 30, 15, "#fff"); tx("Front-end + Design", 700, 306, 13, BL); rr(690, 334, 84, 28, 14, BL); tx("React", 716, 353, 13, "#fff");
          rr(784, 334, 104, 28, 14, "#fff"); tx("UI Design", 805, 353, 13, BL); } },
      { w: 0.35, f: 0.6, x: 0, y: 406, W: SW, h: 56,
        wf: function () { for (var i = 0; i < 4; i++) rr(48 + i * 150, 420, 130, 30, 15, null, WF); },
        fn: function () { var ws = [112, 112, 150, 126], x = 48; ["Front-end", "UI Design", "Landing pages", "Responsivo"].forEach(function (n, i) {
          rr(x, 420, ws[i], 30, 15, "#eef0f9"); tx(n, x + 18, 440, 13, BL, 600); x += ws[i] + 14; }); } },
      { w: 0.37, f: 0.62, x: 0, y: 486, W: SW, h: 134,
        wf: function () { wb(48, 500, 150, 10); wb(48, 530, 380, 28); wb(48, 572, 260, 28); },
        fn: function () { tx("PROJETOS SELECIONADOS", 48, 508, 11, "#646a77"); tx("Ideias que ganham", 48, 556, 38, INK); tx("forma digital.", 48, 600, 38, BL); } },
      cardEl(0, 0.39, 0.64), cardEl(1, 0.4, 0.67), cardEl(2, 0.41, 0.7),
      { w: 0.43, f: 0.73, x: 0, y: 896, W: SW, h: 180,
        wf: function () { circ(110, 980, 60, null, WF); wb(220, 942, 100, 10); wb(220, 966, 480, 18); wb(220, 996, 440, 10); wb(220, 1016, 400, 10); },
        fn: function () { circ(110, 980, 60, BL); tx("LF", 76, 1000, 52, "#fff", 800); tx("SOBRE", 220, 948, 11, "#646a77");
          tx("Código limpo e design", 220, 986, 28, INK); tx("com intenção.", 220, 1020, 28, BL); tx("Cada projeto nasce de uma conversa e termina no ar.", 220, 1052, 15, GR, 400); } },
      { w: 0.45, f: 0.76, x: 0, y: 1096, W: SW, h: 198,
        wf: function () { rr(48, 1110, 928, 170, 8, null, WF); wb(90, 1150, 320, 24); rr(90, 1210, 190, 42, 6, null, WF); },
        fn: function () { rr(48, 1110, 928, 170, 12, "#151722"); tx("Vamos criar o seu site?", 90, 1184, 34, "#fff"); rr(90, 1210, 210, 42, 6, "#9ca8ec"); tx("Chamar no WhatsApp", 112, 1236, 13, "#151722"); } },
      { w: 0.47, f: 0.79, x: 0, y: 1298, W: SW, h: 82,
        wf: function () { wb(48, 1330, 150, 10); wb(780, 1330, 196, 10); },
        fn: function () { tx("© 2026 Luiz Felipe", 48, 1340, 12, "#777d8a", 500); tx("Design digital com propósito.", 770, 1340, 12, "#777d8a", 500); } }
    ];

    var CODE = ["export default function Portfolio() {", "  return (", "    <main className=\"portfolio\">", "      <Nav />", "      <Hero",
      "        titulo=\"Desenvolvedor com olhar de designer.\"", "        botao=\"Ver projetos\"", "      />", "      <Skills />", "      <Projetos />",
      "      <Sobre />", "      <Contato />", "    </main>", "  )", "}"];
    var CTOT = CODE.reduce(function (a, l) { return a + l.length + 1; }, 0);
    function editor(p) {
      g.fillStyle = "#12141f"; g.fillRect(0, CH, SW, VH); g.fillStyle = "#0d0f18"; g.fillRect(0, CH, 190, VH);
      tx("ARQUIVOS", 16, CH + 28, 10, "#6b7190");
      ["index.html", "styles.css", "Portfolio.tsx"].forEach(function (n, i) {
        if (i === 2) rr(8, CH + 44 + i * 30, 174, 26, 5, "#1d2135");
        tx(n, 20, CH + 62 + i * 30, 13, i === 2 ? "#e4e7f5" : "#7d84a3", 500, MONO);
      });
      rr(190, CH, 176, 30, 0, "#1a1d2e"); tx("Portfolio.tsx", 208, CH + 20, 12, "#c9cde0", 500, MONO);
      var left = Math.floor(cl(p / 0.24) * CTOT), ex = 252, ey = CH + 74;
      for (var i = 0; i < CODE.length && left > 0; i++) {
        var s = CODE[i].slice(0, left); left -= CODE[i].length + 1;
        var y = CH + 74 + i * 26, x = 252;
        g.font = "500 13px " + MONO; g.fillStyle = "#4a4f6a"; g.fillText(String(i + 1), 236 - g.measureText(String(i + 1)).width, y);
        var toks = s.match(/"[^"]*"?|<\/?\w*|\/>|\b(?:export|default|function|return)\b|\s+|\w+|./g) || [];
        for (var k = 0; k < toks.length; k++) {
          var t = toks[k], col = t.charAt(0) === "\"" ? "#c3e88d" : t.charAt(0) === "<" || t === "/>" ? "#82aaff" : /^(export|default|function|return)$/.test(t) ? "#c792ea" : "#cfd3e6";
          g.fillStyle = col; g.fillText(t, x, y); x += g.measureText(t).width;
        }
        ex = x; ey = y;
      }
      if (p < 0.24) rr(ex + 2, ey - 13, 8, 17, 1, "#9ca8ec");
      g.fillStyle = BL; g.fillRect(0, SH - 26, SW, 26); tx("● Construindo o site…", 14, SH - 9, 11, "#fff", 600);
      rr(SW - 240, SH - 16, 200, 6, 3, "rgba(255,255,255,.3)"); rr(SW - 240, SH - 16, Math.max(6, 200 * cl(p / 0.3)), 6, 3, "#fff");
    }

    function draw(p) {
      g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.fillStyle = "#fff"; g.fillRect(0, 0, SW, SH);
      var ba = ss((p - 0.26) / 0.05);
      editor(p);
      if (ba > 0) {
        g.save(); g.beginPath(); g.rect(0, CH, SW, VH); g.clip();
        g.globalAlpha = ba; g.fillStyle = "#fff"; g.fillRect(0, CH, SW, VH);
        g.translate(0, CH - (PH - VH) * ss((p - 0.3) / 0.54) * (1 - ss((p - 0.88) / 0.12)));
        for (var i = 0; i < els.length; i++) {
          var e = els[i], aw = cl((p - e.w) / 0.04), af = cl((p - e.f) / 0.05);
          if (aw > 0 && af < 1) { g.globalAlpha = ba * aw; e.wf(); }
          if (af > 0) { g.globalAlpha = ba * af; g.fillStyle = "#fff"; g.fillRect(e.x, e.y, e.W, e.h); e.fn(); }
        }
        g.restore();
      }
      g.globalAlpha = 1; g.fillStyle = "#191c2b"; g.fillRect(0, 0, SW, CH);
      g.globalAlpha = ba; g.fillStyle = "#eef0f6"; g.fillRect(0, 0, SW, CH); g.globalAlpha = 1;
      ["#ff6b6b", "#ffd166", "#4cd18a"].forEach(function (c, i) { circ(24 + i * 22, 22, 6, c); });
      var lt = ba > 0.5;
      if (!lt) tx("Portfolio.tsx — Editor", 150, 27, 13, "#8d93ad", 500);
      else { rr(150, 9, 470, 26, 13, "#fff"); tx("https://luizfelipe.dev", 170, 27, 13, "#6b7080", 500); }
      var st = p < 0.26 ? 0 : p < 0.5 ? 1 : p < 0.8 ? 2 : 3;
      ["Código", "Wireframe", "Design", "Publicado"].forEach(function (n, i) {
        var on = i === st;
        circ(662 + i * 92, 22, 4, on ? (lt ? BL : "#9ca8ec") : (lt ? "#c3c7d6" : "#41465e"));
        tx(n, 672 + i * 92, 26, 11, on ? (lt ? BL : "#c9cff5") : (lt ? "#9aa0b4" : "#6b7190"), on ? 700 : 500);
      });
      var ta = cl((p - 0.86) / 0.04);
      if (ta > 0) { g.globalAlpha = ta; rr(SW - 204, SH - 58, 180, 34, 17, "#1f9d62"); tx("✓ Site publicado", SW - 178, SH - 36, 13, "#fff"); g.globalAlpha = 1; }
      tex.needsUpdate = true;
    }

    /* ---------- notebook 3D ---------- */
    var rig = new T.Group(); sc.add(rig);
    var alu = new T.MeshStandardMaterial({ color: 0xc9cde0, metalness: 0.6, roughness: 0.35 });
    var drk = new T.MeshStandardMaterial({ color: 0x10121a, metalness: 0.3, roughness: 0.6 });
    rig.add(new T.Mesh(new T.BoxGeometry(4, 0.14, 2.7), alu));
    var kc = D.createElement("canvas"); kc.width = 560; kc.height = 200; var kg = kc.getContext("2d");
    kg.fillStyle = "#10121a"; kg.fillRect(0, 0, 560, 200);
    for (var ry = 0; ry < 5; ry++) for (var cx = 0; cx < 14; cx++) { kg.fillStyle = "#262a3b"; kg.fillRect(6 + cx * 39.4, 8 + ry * 38, 34, 32); }
    var kb = new T.Mesh(new T.PlaneGeometry(3.5, 1.25), new T.MeshBasicMaterial({ map: new T.CanvasTexture(kc) }));
    kb.rotation.x = -Math.PI / 2; kb.position.set(0, 0.075, -0.2); rig.add(kb);
    var tp = new T.Mesh(new T.PlaneGeometry(1.2, 0.7), new T.MeshStandardMaterial({ color: 0xaeb3c8, metalness: 0.5, roughness: 0.4 }));
    tp.rotation.x = -Math.PI / 2; tp.position.set(0, 0.075, 0.85); rig.add(tp);
    var hinge = new T.Group(); hinge.position.set(0, 0.07, -1.3); rig.add(hinge);
    var lid = new T.Mesh(new T.BoxGeometry(4, 2.5, 0.08), alu); lid.position.set(0, 1.25, 0); hinge.add(lid);
    var bz = new T.Mesh(new T.PlaneGeometry(3.9, 2.4), drk); bz.position.set(0, 1.25, 0.041); hinge.add(bz);
    var scr = new T.Mesh(new T.PlaneGeometry(3.7, 2.31), new T.MeshBasicMaterial({ map: tex })); scr.position.set(0, 1.25, 0.045); hinge.add(scr);
    draw(0);
    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { last = -1; });

    function rs() { var w = W.innerWidth, h = W.innerHeight; r.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
    W.addEventListener("resize", rs); rsH = rs; rs();

    var sp = 0, last = 0, lastOp = "", t0 = performance.now();
    (function loop() {
      if (stopped) return;
      var t = (performance.now() - t0) / 1000;
      var mx = Math.max(1, D.documentElement.scrollHeight - W.innerHeight);
      sp += (cl(W.scrollY / mx) - sp) * (rm ? 1 : 0.09);
      var w = W.innerWidth, h = W.innerHeight, upp = 6.308 / h, mob = w / h < 0.9, wide = w >= 1100;
      var open = rm ? 1 : ss(t / 1.6);
      hinge.rotation.x = 1.5708 - (1.5708 + 0.3) * open;
      var sm = ss(sp / 0.12);
      var hs = mob ? 0.62 : 1, hx = mob ? 0 : 2.5, hy = -1.25 * hs, tS, tX, tY;
      if (wide) {
        var gu = Math.min(420, Math.max(300, w * 0.27));
        tS = Math.min(1.05, Math.max(0.5, 0.9 * gu * upp / 4.6)); tX = (w / 2 - gu / 2) * upp; tY = -1.25 * tS;
      } else {
        var dh = Math.min(260, Math.max(170, h * 0.3));
        tS = Math.min(0.86 * dh * upp / 3, 0.8 * w * upp / 4.6); tX = 0; tY = -(h / 2 - dh / 2) * upp - 1.25 * tS;
      }
      var s = hs + (tS - hs) * sm;
      rig.scale.setScalar(s);
      rig.position.x = hx + (tX - hx) * sm;
      rig.position.y = hy + (tY - hy) * sm + (rm ? 0 : Math.sin(t * 0.9) * 0.07);
      rig.rotation.y = -0.3 + Math.sin(sp * Math.PI) * 0.6 + (rm ? 0 : Math.sin(t * 0.4) * 0.04);
      rig.rotation.x = 0.08 + sp * 0.1;
      if (Math.abs(sp - last) > 0.0012 || last < 0) { draw(sp); last = sp; }
      var dk = (wide ? 0 : sm).toFixed(3); if (dk !== lastOp) { dock.style.opacity = dk; lastOp = dk; }
      r.render(sc, cam);
      rafId = requestAnimationFrame(loop);
    })();
    return cleanup;
  } catch (e) { cleanup(); onFail(); return function () {}; }
}


const faqs = [
    { q: "Preciso ter textos e imagens prontos?", a: "Não necessariamente. Conversamos sobre o seu negócio e ajudamos a organizar o conteúdo. Materiais que você já tiver, como logo, fotos e textos, ajudam a acelerar o projeto." },
    { q: "O site vai funcionar bem no celular?", a: "Sim. Todos os projetos são pensados para funcionar bem em celular, tablet e computador." },
    { q: "Quanto custa e quanto tempo leva?", a: "Depende do tamanho e do conteúdo do projeto. Depois da primeira conversa, enviamos uma estimativa de investimento e de prazo para você avaliar." },
    { q: "Posso pedir ajustes antes de publicar?", a: "Sim. A etapa de revisão faz parte do processo: ajustamos os detalhes com você antes do lançamento." },
    { q: "Como eu começo?", a: "Preencha o formulário ou chame no WhatsApp. Você conta sobre o negócio e a ideia, e a gente combina os próximos passos." },
]

function Arrow({ diagonal = false }: { diagonal?: boolean }) {
    return <span aria-hidden="true" style={{ display: "inline-block", transform: diagonal ? "rotate(-45deg)" : undefined }}>↗</span>
}

function ProjectVisual({ theme }: { theme: string }) {
    const palettes: Record<string, { bg: string; accent: string; ink: string; label: string }> = {
        beauty: { bg: "#E9E5F2", accent: "#B9A9D2", ink: "#292438", label: "ALVA" },
        architecture: { bg: "#E8E7E2", accent: "#A5A08F", ink: "#282722", label: "NORTE" },
        business: { bg: "#E6EAF4", accent: C.blue, ink: "#19213E", label: "VÉRTICE" },
    }
    const p = palettes[theme] || palettes.business
    return (
        <div className={`lfga-project-visual ${theme}`} style={{ background: p.bg }}>
            <div className="lfga-browser"><i /><i /><i /><span>www.{p.label.toLowerCase()}.com.br</span></div>
            <div className="lfga-project-screen" style={{ color: p.ink }}>
                <div className="lfga-mini-nav"><b>{p.label}</b><span>Sobre&nbsp;&nbsp; Serviços&nbsp;&nbsp; Contato</span></div>
                <div className="lfga-mini-copy"><small>UMA NOVA FORMA DE FAZER</small><strong>{theme === "beauty" ? "Cuidado que" : theme === "architecture" ? "Espaços com" : "Clareza para"}<br />{theme === "beauty" ? "começa em você." : theme === "architecture" ? "intenção." : "ir mais longe."}</strong><em style={{ background: p.accent }}>Conheça</em></div>
                <div className="lfga-orb" style={{ background: p.accent }} />
            </div>
            <span className="lfga-concept-tag">PROJETO CONCEITUAL</span>
        </div>
    )
}

/**
 * @framerSupportedLayoutWidth any
 * @framerSupportedLayoutHeight auto
 * @framerIntrinsicWidth 1440
 */
export default function LFGAMidiasLanding(props: { style?: React.CSSProperties }) {
    const [notice, setNotice] = React.useState("")
    const [has3d, setHas3d] = React.useState(true)
    const rootRef = React.useRef<HTMLElement>(null)

    React.useEffect(() => {
        const root = rootRef.current
        if (!root) return
        try { if (RenderTarget.current() === RenderTarget.canvas) { setHas3d(false); return } } catch (e) {}
        let off = () => {}
        let cancelled = false
        import("https://esm.sh/three@0.128.0")
            .then((mod) => {
                if (cancelled) return
                try { off = startScene(mod, root, () => setHas3d(false)) } catch (e) { setHas3d(false) }
            })
            .catch(() => setHas3d(false))
        return () => { cancelled = true; off() }
    }, [])

    React.useEffect(() => {
        const root = rootRef.current
        if (!root) return
        const hero = root.querySelector(".lfga-hero") as HTMLElement | null
        const header = root.querySelector(".lfga-header") as HTMLElement | null
        const setTop = () => {
            if (header) root.style.setProperty("--lfga-hh", header.offsetHeight + "px")
            if (hero) root.style.setProperty("--lfga-top", hero.offsetTop + hero.offsetHeight + "px")
        }
        let lastY = window.scrollY
        const onScroll = () => {
            const y = window.scrollY, d = y - lastY
            root.classList.toggle("lfga-scrolled", y > 24)
            if (y < 80 || d < -4) root.classList.remove("lfga-hide")
            else if (d > 4 && y > 160) root.classList.add("lfga-hide")
            if (Math.abs(d) > 4) lastY = y
        }
        let raf = 0
        const onMove = (e: MouseEvent) => {
            cancelAnimationFrame(raf)
            raf = requestAnimationFrame(() => {
                const r = root.getBoundingClientRect()
                root.style.setProperty("--mx", e.clientX - r.left + "px")
                root.style.setProperty("--my", e.clientY - r.top + "px")
            })
        }
        setTop(); onScroll()
        const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(setTop) : null
        if (ro && hero) ro.observe(hero)
        if (ro && header) ro.observe(header)
        window.addEventListener("resize", setTop)
        window.addEventListener("scroll", onScroll, { passive: true })
        const fine = window.matchMedia("(pointer: fine) and (prefers-reduced-motion: no-preference)").matches
        if (fine) window.addEventListener("mousemove", onMove, { passive: true })
        return () => {
            cancelAnimationFrame(raf); ro?.disconnect()
            window.removeEventListener("resize", setTop); window.removeEventListener("scroll", onScroll); window.removeEventListener("mousemove", onMove)
        }
    }, [])

    React.useEffect(() => {
        const root = rootRef.current
        if (!root || typeof IntersectionObserver === "undefined" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return
        const els = root.querySelectorAll(".lfga-section-head, .lfga-project-card, .lfga-service-list article, .lfga-steps article, .lfga-about-copy, .lfga-faq-list details, .lfga-contact-copy, .lfga-form")
        const io = new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("lfga-in"); io.unobserve(e.target) } }), { threshold: 0.12 })
        els.forEach((el, i) => { el.classList.add("lfga-rv"); (el as HTMLElement).style.transitionDelay = `${(i % 3) * 70}ms`; io.observe(el) })
        return () => io.disconnect()
    }, [])

    function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
        event.preventDefault()
        const data = new FormData(event.currentTarget)
        const lines = [
            "Olá! Vim pelo site da LFGAMidias e quero conversar sobre um projeto.",
            `Nome: ${data.get("nome")}`,
            `E-mail: ${data.get("email") || "Não informado"}`,
            `WhatsApp: ${data.get("telefone")}`,
            `Projeto: ${data.get("tipo")}`,
            `Prazo: ${data.get("prazo")}`,
            `Investimento previsto: ${data.get("investimento") || "Não informado"}`,
            `Detalhes: ${data.get("detalhes") || "Não informado"}`,
        ].join("\n")
        if (!waConfigured) {
            setNotice("Adicione seu número na constante WHATSAPP_NUMBER no início do código para ativar o envio.")
            return
        }
        window.open(`${waBase}?text=${encodeURIComponent(lines)}`, "_blank", "noopener,noreferrer")
        setNotice("Sua mensagem está pronta no WhatsApp. Revise e envie por lá.")
    }

    return (
        <main className="lfga-site" style={props.style} ref={rootRef}>
            <style>{styles}</style>
            <header className="lfga-header">
                <a href="#inicio" className="lfga-brand" aria-label="LFGAMidias, início">
                    {LOGO_URL ? <img src={LOGO_URL} alt="LFGAMidias" className="lfga-logo-image" /> : <span className="lfga-brand-mark">LF</span>}<span>LFGAMidias<small>ESTÚDIO DIGITAL</small></span>
                </a>
                <nav className="lfga-nav" aria-label="Navegação principal">
                    <a href="#projetos">Projetos</a><a href="#servicos">Serviços</a><a href="#sobre">Sobre</a><a href="#faq">Dúvidas</a><a href="#contato">Contato</a>
                </nav>
                <a className="lfga-header-cta" href={waBase}>Vamos conversar <Arrow /></a>
            </header>

            <section className="lfga-hero" id="inicio">
                <div className="lfga-hero-copy">
                    <div className="lfga-eyebrow"><span /> DESIGN DIGITAL PARA NEGÓCIOS EM MOVIMENTO</div>
                    <h1>Sites que transformam visitantes em <em>clientes.</em></h1>
                    <p>Criamos sites e landing pages com estratégia, design e desenvolvimento para apresentar o valor do seu negócio e levar o visitante a entrar em contato.</p>
                    <div className="lfga-hero-actions"><a className="lfga-button lfga-button-primary" href="#contato">Tirar meu projeto do papel <Arrow /></a><a className="lfga-text-link" href="#projetos">Explorar projetos <span>↓</span></a></div>
                    <div className="lfga-hero-note"><span className="lfga-note-check">✓</span> Atendimento próximo, do primeiro rascunho ao lançamento</div>
                </div>
                {has3d ? <div className="lfga-hero-slot" role="img" aria-label="Notebook 3D com um site sendo construído conforme a página rola" /> : (<div className="lfga-hero-art" aria-label="Prévia ilustrativa de um site em construção">
                    <div className="lfga-art-glow" />
                    <div className="lfga-art-label"><span>01 / PRESENÇA DIGITAL</span><span>ESTRATÉGIA + DESIGN</span></div>
                    <div className="lfga-device">
                        <div className="lfga-device-top"><span className="lfga-brand-mark small">LF</span><span>SEU NEGÓCIO, EM DESTAQUE</span><span>MENU&nbsp; ☰</span></div>
                        <div className="lfga-device-body"><small>UMA PRESENÇA À ALTURA DA SUA IDEIA</small><strong>Feito para<br /><i>ir mais longe.</i></strong><p>Um site pensado para conectar sua marca com as pessoas certas.</p><span className="lfga-device-button">Conheça o projeto&nbsp; ↗</span><div className="lfga-device-shape"><b>LF</b></div></div>
                    </div>
                    <div className="lfga-art-stamp"><b>LFGA</b><span>WEB DESIGN<br />& ESTRATÉGIA</span></div>
                    <div className="lfga-art-index">DESLIZE PARA EXPLORAR <span>↓</span></div>
                </div>)}
            </section>

            <section className="lfga-proof-strip"><span>DO PRIMEIRO CLIQUE AO PRIMEIRO CONTATO</span><div><b>01</b> Estratégia clara</div><div><b>02</b> Design com intenção</div><div><b>03</b> Experiência responsiva</div></section>

            <section className="lfga-section lfga-work" id="projetos">
                <div className="lfga-section-head"><div><div className="lfga-eyebrow"><span /> PORTFÓLIO</div><h2>Ideias que ganham<br /><em>forma digital.</em></h2></div><p>Estudos conceituais para mostrar como estratégia e design podem transformar a presença de diferentes negócios.</p></div>
                <div className="lfga-project-grid">{projects.map((p) => <article className="lfga-project-card" key={p.n}><ProjectVisual theme={p.theme} /><div className="lfga-project-meta"><div><span>{p.n} / CONCEITO</span><h3>{p.name}</h3><p>{p.type}</p></div><a href="#contato" aria-label={`Conversar sobre um projeto como ${p.name}`}><Arrow diagonal /></a></div></article>)}</div>
                <p className="lfga-project-disclaimer">Os exemplos acima são estudos conceituais, criados para apresentação visual. Não representam clientes ou resultados reais.</p>
            </section>

            <section className="lfga-services" id="servicos"><div className="lfga-section-head light"><div><div className="lfga-eyebrow"><span /> O QUE FAZEMOS</div><h2>Uma presença digital<br />que trabalha pelo seu <em>negócio.</em></h2></div><p>Do planejamento ao último detalhe, cada entrega parte das necessidades reais da sua empresa.</p></div>
                <div className="lfga-service-list"><article><span>01</span><div><h3>Sites institucionais</h3><p>Apresente sua empresa com confiança, organize suas informações e facilite o próximo passo do cliente.</p></div><b>↗</b></article><article><span>02</span><div><h3>Landing pages</h3><p>Uma página focada em uma oferta, campanha ou serviço, com conteúdo organizado para guiar a decisão.</p></div><b>↗</b></article><article><span>03</span><div><h3>Redesign de sites</h3><p>Atualize a experiência, a estrutura e a identidade visual do seu site para acompanhar a evolução do negócio.</p></div><b>↗</b></article></div>
            </section>

            <section className="lfga-process"><div className="lfga-process-intro"><div className="lfga-eyebrow"><span /> COMO ACONTECE</div><h2>Da conversa ao<br /><em>site no ar.</em></h2><p>Um processo simples, transparente e construído em parceria com você.</p><a className="lfga-text-link" href="#contato">Começar uma conversa <Arrow /></a></div><div className="lfga-steps"><article><span>01</span><div><h3>Entendimento</h3><p>Conhecemos seu negócio, seus objetivos e o público que você quer alcançar.</p></div></article><article><span>02</span><div><h3>Estratégia & direção</h3><p>Definimos estrutura, conteúdo e direção visual para o projeto.</p></div></article><article><span>03</span><div><h3>Design & construção</h3><p>Transformamos o planejamento em uma experiência digital clara e responsiva.</p></div></article><article><span>04</span><div><h3>Revisão & lançamento</h3><p>Ajustamos os detalhes com você e preparamos tudo para publicar.</p></div></article></div></section>

            <section className="lfga-about" id="sobre"><div className="lfga-about-mark">LF<span>GA</span></div><div className="lfga-about-copy"><div className="lfga-eyebrow"><span /> SOBRE A LFGAMIDIAS</div><h2>Seu negócio merece ser visto com <em>clareza.</em></h2><p>A LFGAMidias é um estúdio digital dedicado a criar sites e landing pages para negócios que querem começar bem ou dar um novo passo. Unimos cuidado visual e pensamento estratégico para construir experiências que fazem sentido para quem visita e para quem empreende.</p><a className="lfga-button lfga-button-outline" href="#contato">Conte sobre sua ideia <Arrow /></a></div></section>

            <section className="lfga-section lfga-faq" id="faq"><div className="lfga-section-head"><div><div className="lfga-eyebrow"><span /> DÚVIDAS FREQUENTES</div><h2>Antes de começar,<br /><em>algumas respostas.</em></h2></div><p>Não encontrou o que procurava? É só chamar e conversamos sobre o seu projeto.</p></div>
                <div className="lfga-faq-list">{faqs.map((f) => <details key={f.q}><summary>{f.q}</summary><p>{f.a}</p></details>)}</div>
            </section>

            <section className="lfga-contact" id="contato"><div className="lfga-contact-copy"><div className="lfga-eyebrow light"><span /> PRÓXIMO PASSO</div><h2>Vamos falar sobre<br />o seu <em>projeto?</em></h2><p>Responda algumas perguntas rápidas. Assim já entendemos o que você precisa e podemos direcionar a conversa.</p><a className="lfga-contact-wa" href={waBase}>Prefere conversar direto? <b>Chame no WhatsApp <Arrow /></b></a>{!waConfigured && <small className="lfga-setup-hint">WhatsApp: substitua o placeholder no código pelo seu número com DDI e DDD.</small>}</div>
                <form className="lfga-form" onSubmit={handleSubmit}><div className="lfga-form-title"><span>FORMULÁRIO DE PROJETO</span><span>~ 2 MIN</span></div><label>Seu nome<input name="nome" placeholder="Como podemos chamar você?" required /></label><div className="lfga-form-row"><label>E-mail <span className="lfga-optional">opcional</span><input name="email" type="email" placeholder="voce@empresa.com" /></label><label>WhatsApp<input name="telefone" type="tel" placeholder="(00) 00000-0000" required /></label></div><label>O que você precisa?<select name="tipo" defaultValue="" required><option value="" disabled>Selecione uma opção</option><option>Site institucional</option><option>Landing page</option><option>Redesign de site</option><option>Ainda não tenho certeza</option></select></label><div className="lfga-form-row"><label>Quando pretende começar?<select name="prazo" defaultValue="" required><option value="" disabled>Selecione</option><option>O quanto antes</option><option>Nos próximos 30 dias</option><option>Em 1 a 3 meses</option><option>Estou pesquisando</option></select></label><label>Investimento previsto <span className="lfga-optional">opcional</span><select name="investimento" defaultValue=""><option value="" disabled>Selecione</option><option>Até R$ 2.000</option><option>R$ 2.000 – R$ 5.000</option><option>R$ 5.000 – R$ 10.000</option><option>Acima de R$ 10.000</option><option>Quero conversar sobre isso</option></select></label></div><label>Conte um pouco da sua ideia <span className="lfga-optional">opcional</span><textarea name="detalhes" rows={3} placeholder="O que seria importante sabermos?" /></label><button className="lfga-button lfga-button-primary" type="submit">Enviar pelo WhatsApp <Arrow /></button>{notice && <p className="lfga-notice" role="status">{notice}</p>}<small className="lfga-privacy">Ao enviar, você autoriza o uso destas informações para entrarmos em contato sobre seu projeto.</small></form>
            </section>

            <footer className="lfga-footer"><a href="#inicio" className="lfga-brand">{LOGO_URL ? <img src={LOGO_URL} alt="LFGAMidias" className="lfga-logo-image" /> : <span className="lfga-brand-mark">LF</span>}<span>LFGAMidias<small>ESTÚDIO DIGITAL</small></span></a><span>Design digital com propósito.</span><div><a href="#projetos">Projetos</a><a href="#servicos">Serviços</a><a href="#sobre">Sobre</a><a href="#faq">Dúvidas</a><a href="#contato">Contato</a></div><small>© {new Date().getFullYear()} LFGAMidias. Todos os direitos reservados.</small></footer>
        </main>
    )
}

const styles = `
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap');
.lfga-site{--blue:${C.blue};--lav:${C.lavender};--slate:${C.slate};--paper:${C.paper};--ink:${C.ink};--white:${C.white};font-family:'DM Sans',Arial,sans-serif;color:var(--ink);background:#fff;width:100%;overflow:hidden;font-size:15px;line-height:1.6}.lfga-logo-image{width:38px;height:38px;object-fit:contain;display:block}
.lfga-site *{box-sizing:border-box}.lfga-site a{color:inherit;text-decoration:none}.lfga-site h1,.lfga-site h2,.lfga-site h3,.lfga-site p{margin-top:0}.lfga-site h1,.lfga-site h2,.lfga-site h3{font-family:'Manrope','DM Sans',sans-serif;letter-spacing:-.045em;line-height:1.04}.lfga-header{height:84px;max-width:1280px;margin:auto;padding:0 38px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #ececf0}.lfga-brand{display:flex;align-items:center;gap:10px;font-family:Manrope,sans-serif;font-weight:800;letter-spacing:-.04em;font-size:17px;line-height:1.05}.lfga-brand small{display:block;font:600 8px 'DM Sans',sans-serif;letter-spacing:.16em;color:#777e91;margin-top:5px}.lfga-brand-mark{width:34px;height:34px;border-radius:10px;background:var(--blue);color:white;display:grid;place-items:center;font:800 12px Manrope,sans-serif;letter-spacing:-.08em}.lfga-brand-mark.small{width:26px;height:26px;border-radius:7px;font-size:10px}.lfga-nav{display:flex;gap:34px;font-size:13px;color:#555b68}.lfga-nav a:hover,.lfga-footer a:hover{color:var(--blue)}.lfga-header-cta{border:1px solid #d9dbe3;padding:11px 16px;border-radius:7px;font-size:12px;font-weight:700}.lfga-header-cta:hover{background:var(--blue);border-color:var(--blue);color:#fff!important}.lfga-hero{max-width:1280px;min-height:635px;margin:auto;padding:72px 38px 64px;display:grid;grid-template-columns:.94fr 1.06fr;align-items:center;gap:40px}.lfga-eyebrow{display:flex;align-items:center;gap:9px;color:#646a77;font-size:10px;letter-spacing:.14em;font-weight:700}.lfga-eyebrow>span{width:7px;height:7px;border-radius:50%;background:var(--blue);box-shadow:0 0 0 4px #2b3a8c16}.lfga-eyebrow.light{color:#c1c7de}.lfga-hero h1{font-size:clamp(48px,6vw,76px);max-width:580px;margin:27px 0 22px;font-weight:700}.lfga-hero h1 em,.lfga-section-head h2 em,.lfga-process h2 em,.lfga-about h2 em,.lfga-contact h2 em{color:var(--blue);font-style:normal}.lfga-hero-copy>p{max-width:470px;color:#626875;font-size:16px;line-height:1.8}.lfga-hero-actions{display:flex;align-items:center;gap:24px;margin-top:31px}.lfga-button{min-height:48px;border:0;border-radius:6px;padding:0 18px;display:inline-flex;align-items:center;justify-content:center;gap:18px;font:700 12px 'DM Sans',sans-serif;cursor:pointer;transition:.2s}.lfga-button-primary{background:var(--blue);color:#fff!important}.lfga-button-primary:hover{background:#1f2c72;transform:translateY(-2px)}.lfga-text-link{font-weight:700;font-size:12px;display:inline-flex;align-items:center;gap:10px}.lfga-text-link span{font-size:16px}.lfga-hero-note{display:flex;align-items:center;gap:10px;color:#747a86;font-size:11px;margin-top:45px}.lfga-note-check{width:20px;height:20px;border-radius:50%;display:grid;place-items:center;background:#edf0fb;color:var(--blue);font-size:12px}.lfga-hero-art{position:relative;min-height:460px;display:grid;place-items:center;background:#f4f5f9;border-radius:4px;overflow:hidden}.lfga-hero-art:before,.lfga-hero-art:after{content:'';position:absolute;border:1px solid #dfe2ed;border-radius:50%;width:410px;height:410px}.lfga-hero-art:after{width:540px;height:540px;border-color:#e7e9f0}.lfga-art-glow{position:absolute;width:330px;height:330px;border-radius:50%;background:#e3e6f5;filter:blur(1px)}.lfga-art-label,.lfga-art-index{position:absolute;left:25px;right:25px;top:20px;display:flex;justify-content:space-between;color:#777e91;font-size:8px;letter-spacing:.12em;font-weight:700;z-index:2}.lfga-device{position:relative;z-index:1;width:min(78%,460px);min-height:310px;background:white;border:1px solid #e5e6ec;border-radius:8px;box-shadow:0 28px 70px #1822581d;transform:rotate(-3deg);overflow:hidden}.lfga-device-top{height:41px;border-bottom:1px solid #eee;display:flex;align-items:center;justify-content:space-between;padding:0 14px;font-size:7px;color:#898d98;letter-spacing:.08em}.lfga-device-body{padding:29px 28px;position:relative;min-height:270px;overflow:hidden}.lfga-device-body>small{font-size:7px;letter-spacing:.16em;color:#72788b;font-weight:700}.lfga-device-body>strong{display:block;font:800 38px/1.03 Manrope,sans-serif;letter-spacing:-.07em;margin:13px 0}.lfga-device-body>strong i{color:var(--blue);font-style:normal}.lfga-device-body>p{font-size:9px;color:#717887;max-width:210px}.lfga-device-button{display:inline-block;background:var(--blue);color:white;padding:8px 10px;border-radius:3px;font-size:7px;margin-top:9px}.lfga-device-shape{position:absolute;width:155px;height:180px;border-radius:80px 80px 8px 8px;background:linear-gradient(145deg,#8791c5,var(--blue));right:16px;bottom:-43px;transform:rotate(12deg);display:grid;place-items:center;color:#ffffff5d;font:800 50px Manrope,sans-serif}.lfga-art-stamp{position:absolute;right:18px;bottom:52px;z-index:2;width:94px;height:94px;border-radius:50%;background:var(--blue);color:white;display:flex;flex-direction:column;align-items:center;justify-content:center;transform:rotate(9deg);box-shadow:0 8px 24px #2b3a8c44}.lfga-art-stamp b{font:800 19px Manrope,sans-serif;letter-spacing:-.1em}.lfga-art-stamp span{text-align:center;font-size:6px;line-height:1.5;letter-spacing:.1em;margin-top:4px}.lfga-art-index{top:auto;bottom:20px}.lfga-art-index span{font-size:14px}.lfga-proof-strip{max-width:1280px;margin:auto;border-top:1px solid #e9eaf0;border-bottom:1px solid #e9eaf0;min-height:86px;padding:17px 38px;display:flex;align-items:center;justify-content:space-between;gap:16px;color:#555b68;font-size:12px}.lfga-proof-strip>span{font-size:9px;letter-spacing:.13em;color:#7e8491;font-weight:700}.lfga-proof-strip div{display:flex;align-items:center;gap:10px}.lfga-proof-strip b{color:var(--blue);font:700 10px Manrope,sans-serif}.lfga-section{max-width:1280px;margin:auto;padding:110px 38px}.lfga-section-head{display:flex;align-items:end;justify-content:space-between;gap:30px;margin-bottom:43px}.lfga-section-head h2,.lfga-process h2,.lfga-about h2,.lfga-contact h2{font-size:clamp(38px,5vw,58px);margin:18px 0 0}.lfga-section-head>p{max-width:350px;color:#6e7480;font-size:13px;line-height:1.8;margin:0 0 3px}.lfga-project-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.lfga-project-visual{height:265px;position:relative;padding:15px;overflow:hidden;border-radius:4px}.lfga-browser{height:25px;border-radius:4px 4px 0 0;background:#fff;display:flex;align-items:center;gap:4px;padding:0 8px;color:#9296a1;font-size:6px}.lfga-browser i{width:5px;height:5px;background:#d6d7de;border-radius:50%}.lfga-browser span{margin-left:8px}.lfga-project-screen{height:calc(100% - 25px);background:#ffffffa8;position:relative;padding:13px 15px;overflow:hidden}.lfga-mini-nav{display:flex;justify-content:space-between;align-items:center;font-size:6px}.lfga-mini-nav b{font:800 10px Manrope,sans-serif}.lfga-mini-copy{position:relative;z-index:1;margin-top:35px}.lfga-mini-copy small{display:block;font-size:5px;letter-spacing:.12em}.lfga-mini-copy strong{display:block;font:700 24px/1.08 Manrope,sans-serif;letter-spacing:-.06em;margin:8px 0}.lfga-mini-copy em{display:inline-block;color:#fff;padding:5px 8px;border-radius:2px;font-style:normal;font-size:6px}.lfga-orb{position:absolute;width:125px;height:125px;border-radius:50%;right:-13px;bottom:-24px;opacity:.75}.architecture .lfga-orb{border-radius:3px;transform:rotate(34deg);width:110px;height:170px;right:27px;bottom:-47px}.business .lfga-orb{width:150px;height:80px;border-radius:80px 80px 0 0;right:-10px;bottom:0}.lfga-concept-tag{position:absolute;left:22px;bottom:20px;font-size:6px;letter-spacing:.13em;font-weight:700;background:#fff;padding:5px 7px;border-radius:2px}.lfga-project-meta{padding:15px 2px 0;display:flex;justify-content:space-between;align-items:center}.lfga-project-meta>div>span{font-size:8px;letter-spacing:.12em;color:#777e8b;font-weight:700}.lfga-project-meta h3{font-size:20px;margin:7px 0 3px}.lfga-project-meta p{font-size:11px;color:#747986;margin:0}.lfga-project-meta>a{width:34px;height:34px;border:1px solid #dfe1e7;border-radius:50%;display:grid;place-items:center;font-size:15px}.lfga-project-disclaimer{margin:22px 0 0;font-size:10px;color:#838894}.lfga-services{background:#101219;color:white;padding:100px max(38px,calc((100% - 1204px)/2)) 95px}.lfga-services .lfga-eyebrow>span{background:#9da8ee;box-shadow:0 0 0 4px #aab2ef1b}.lfga-services .lfga-section-head h2{color:white}.lfga-services .lfga-section-head h2 em{color:#9ca8ec}.lfga-services .lfga-section-head>p{color:#a6a9b2}.lfga-service-list{border-top:1px solid #353741}.lfga-service-list article{display:grid;grid-template-columns:70px 1fr 30px;align-items:start;gap:15px;padding:24px 0;border-bottom:1px solid #353741}.lfga-service-list article>span{font-size:10px;color:#9ba5e4;padding-top:4px}.lfga-service-list h3{font-size:22px;margin:0 0 9px;color:white}.lfga-service-list p{color:#a6a9b2;font-size:12px;margin:0;max-width:590px;line-height:1.7}.lfga-service-list article>b{color:#9ca8ec;font-size:18px}.lfga-process{max-width:1280px;margin:auto;padding:105px 38px;display:grid;grid-template-columns:.85fr 1.15fr;gap:90px}.lfga-process-intro>p{color:#717783;font-size:13px;max-width:320px;line-height:1.8;margin:19px 0 25px}.lfga-steps{border-top:1px solid #e5e6eb}.lfga-steps article{display:grid;grid-template-columns:50px 1fr;gap:15px;padding:19px 0;border-bottom:1px solid #e5e6eb}.lfga-steps article>span{color:var(--blue);font:700 11px Manrope,sans-serif;padding-top:4px}.lfga-steps h3{font-size:17px;margin:0 0 6px}.lfga-steps p{font-size:11px;color:#717783;margin:0;line-height:1.65}.lfga-about{background:#f2f3f7;display:grid;grid-template-columns:1fr 1fr;gap:80px;padding:90px max(38px,calc((100% - 1204px)/2));align-items:center}.lfga-about-mark{height:295px;border-radius:3px;background:var(--blue);display:flex;align-items:center;justify-content:center;color:#fff;font:800 clamp(80px,13vw,155px)/1 Manrope,sans-serif;letter-spacing:-.12em;position:relative;overflow:hidden}.lfga-about-mark:after{content:'';position:absolute;width:290px;height:290px;border:1px solid #ffffff35;border-radius:50%;right:-70px;bottom:-100px;box-shadow:0 0 0 35px #ffffff0c,0 0 0 70px #ffffff08}.lfga-about-mark span{color:#a7b0eb}.lfga-about-copy h2{margin-bottom:19px}.lfga-about-copy>p{font-size:13px;line-height:1.85;color:#646a77;max-width:520px}.lfga-button-outline{border:1px solid #c9ccd7;background:transparent;color:var(--ink);margin-top:10px}.lfga-button-outline:hover{background:var(--blue);color:white;border-color:var(--blue)}.lfga-contact{background:#151722;color:white;padding:100px max(38px,calc((100% - 1204px)/2));display:grid;grid-template-columns:.85fr 1.15fr;gap:80px;align-items:start}.lfga-contact .lfga-eyebrow>span{background:#9da8ee;box-shadow:0 0 0 4px #aab2ef1b}.lfga-contact h2{color:white}.lfga-contact h2 em{color:#9ca8ec}.lfga-contact-copy>p{color:#aaadba;font-size:13px;line-height:1.8;max-width:360px;margin:20px 0 30px}.lfga-contact-wa{display:flex;flex-direction:column;font-size:11px;color:#b7bac6;gap:4px}.lfga-contact-wa b{color:white;font-size:13px}.lfga-setup-hint{display:block;color:#9298b2;font-size:9px;margin-top:14px;max-width:290px}.lfga-form{padding:27px;background:#fff;color:var(--ink);border-radius:5px}.lfga-form-title{display:flex;justify-content:space-between;font-size:8px;letter-spacing:.12em;font-weight:700;color:#7b8190;border-bottom:1px solid #ececf0;padding-bottom:14px;margin-bottom:17px}.lfga-form label{display:block;font-size:10px;font-weight:700;color:#414653;margin-bottom:13px}.lfga-form input,.lfga-form select,.lfga-form textarea{display:block;margin-top:6px;width:100%;border:1px solid #e1e3e9;border-radius:3px;padding:11px 10px;font:400 11px 'DM Sans',sans-serif;color:#282b35;background:white;outline:none}.lfga-form input:focus,.lfga-form select:focus,.lfga-form textarea:focus{border-color:var(--lav);box-shadow:0 0 0 3px #7a85bf1c}.lfga-form input::placeholder,.lfga-form textarea::placeholder{color:#a2a5ae}.lfga-form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.lfga-form textarea{resize:vertical}.lfga-optional{font-weight:400;color:#858a95}.lfga-form>.lfga-button{width:100%;margin-top:2px}.lfga-notice{color:var(--blue);font-size:10px;margin:10px 0 0}.lfga-privacy{display:block;color:#898e98;font-size:8px;line-height:1.5;margin-top:11px}.lfga-footer{max-width:1280px;margin:auto;padding:28px 38px;display:grid;grid-template-columns:1fr 1fr 1fr;align-items:center;gap:20px}.lfga-footer>span{font-size:10px;color:#777d8a}.lfga-footer>div{display:flex;gap:18px;justify-content:flex-end;font-size:10px;color:#646a77}.lfga-footer>small{grid-column:1/-1;color:#9296a0;font-size:9px;border-top:1px solid #ececf0;padding-top:15px}.lfga-footer .lfga-brand{font-size:14px}.lfga-footer .lfga-brand-mark{width:30px;height:30px}
@media(max-width:850px){.lfga-header{padding:0 24px}.lfga-nav{gap:18px}.lfga-hero{padding:58px 24px;grid-template-columns:1fr;gap:34px}.lfga-hero-copy{max-width:650px}.lfga-hero-art{min-height:390px}.lfga-proof-strip{padding:18px 24px;flex-wrap:wrap}.lfga-proof-strip>span{width:100%}.lfga-section{padding:82px 24px}.lfga-services{padding:82px 24px}.lfga-process{padding:82px 24px;gap:45px}.lfga-about,.lfga-contact{padding:75px 24px;gap:38px}.lfga-about-mark{height:250px}}
@media(max-width:600px){.lfga-site{font-size:14px}.lfga-header{height:72px;padding:0 18px}.lfga-brand{font-size:15px}.lfga-brand-mark{width:30px;height:30px}.lfga-nav{display:none}.lfga-header-cta{padding:9px 11px;font-size:10px}.lfga-hero{padding:49px 18px 43px;gap:28px}.lfga-hero h1{font-size:48px;margin:22px 0 16px}.lfga-hero-copy>p{font-size:14px}.lfga-hero-actions{align-items:flex-start;flex-direction:column;gap:16px}.lfga-hero-note{margin-top:27px;font-size:9px}.lfga-hero-art{min-height:315px}.lfga-device{width:82%;min-height:255px}.lfga-device-body{padding:22px 17px;min-height:220px}.lfga-device-body>strong{font-size:30px}.lfga-device-shape{width:115px;height:140px}.lfga-art-stamp{width:74px;height:74px;right:12px;bottom:42px}.lfga-art-stamp b{font-size:15px}.lfga-art-label,.lfga-art-index{left:14px;right:14px;font-size:7px}.lfga-proof-strip{padding:17px 18px;gap:14px}.lfga-proof-strip div{width:calc(50% - 8px);font-size:10px}.lfga-section{padding:70px 18px}.lfga-section-head{display:block;margin-bottom:28px}.lfga-section-head h2,.lfga-process h2,.lfga-about h2,.lfga-contact h2{font-size:40px}.lfga-section-head>p{margin-top:16px}.lfga-project-grid{grid-template-columns:1fr;gap:28px}.lfga-project-visual{height:260px}.lfga-project-disclaimer{font-size:9px;line-height:1.6}.lfga-services{padding:70px 18px}.lfga-service-list article{grid-template-columns:32px 1fr 20px;gap:10px;padding:20px 0}.lfga-service-list h3{font-size:19px}.lfga-service-list p{font-size:11px}.lfga-process{padding:70px 18px;grid-template-columns:1fr;gap:32px}.lfga-about{padding:60px 18px;grid-template-columns:1fr;gap:28px}.lfga-about-mark{height:210px}.lfga-contact{padding:70px 18px;grid-template-columns:1fr;gap:30px}.lfga-form{padding:20px 16px}.lfga-form-row{grid-template-columns:1fr;gap:0}.lfga-footer{padding:25px 18px;grid-template-columns:1fr 1fr}.lfga-footer>span{display:none}.lfga-footer>div{grid-column:1/-1;justify-content:flex-start;flex-wrap:wrap;gap:16px}.lfga-footer>small{grid-column:1/-1}}

/* ---- melhorias v2: leitura, contraste, movimento, FAQ ---- */
.lfga-site{font-size:16px}
.lfga-site [id]{scroll-margin-top:96px}
.lfga-site a:focus-visible,.lfga-site button:focus-visible,.lfga-site summary:focus-visible,.lfga-site input:focus-visible,.lfga-site select:focus-visible,.lfga-site textarea:focus-visible{outline:2px solid var(--lav);outline-offset:3px;border-radius:4px}
.lfga-site .lfga-nav{font-size:14px;color:#4a505c}
.lfga-site .lfga-header-cta{font-size:13px}
.lfga-site .lfga-button,.lfga-site .lfga-text-link{font-size:14px}
.lfga-site .lfga-eyebrow{font-size:11px;color:#565c6a}
.lfga-site .lfga-eyebrow.light{color:#c1c7de}
.lfga-site .lfga-hero-copy>p{font-size:18px;color:#4f5562}
.lfga-site .lfga-hero-note{font-size:13px;color:#5f6674}
.lfga-site .lfga-proof-strip{font-size:14px}
.lfga-site .lfga-proof-strip>span{font-size:11px;color:#5f6674}
.lfga-site .lfga-work .lfga-section-head>p,.lfga-site .lfga-faq .lfga-section-head>p{font-size:15px;color:#4f5562;max-width:380px}
.lfga-site .lfga-services .lfga-section-head>p{font-size:15px;color:#b9bdc9;max-width:380px}
.lfga-site .lfga-service-list p{font-size:14px;color:#b9bdc9}
.lfga-site .lfga-process-intro>p{font-size:15px;color:#4f5562;max-width:360px}
.lfga-site .lfga-steps h3{font-size:19px}
.lfga-site .lfga-steps p{font-size:14px;color:#4f5562}
.lfga-site .lfga-about-copy>p{font-size:15px;color:#4f5562}
.lfga-site .lfga-project-meta p{font-size:13px;color:#5f6674}
.lfga-site .lfga-project-meta>div>span{font-size:10px;color:#5f6674}
.lfga-site .lfga-project-disclaimer{font-size:12px;color:#6b7180}
.lfga-site .lfga-contact-copy>p{font-size:15px;color:#c3c6d2}
.lfga-site .lfga-contact-wa{font-size:13px;color:#c3c6d2}
.lfga-site .lfga-contact-wa b{font-size:15px}
.lfga-site .lfga-setup-hint{font-size:12px;color:#aab0c8}
.lfga-site .lfga-form-title{font-size:10px}
.lfga-site .lfga-form label{font-size:13px}
.lfga-site .lfga-form input,.lfga-site .lfga-form select,.lfga-site .lfga-form textarea{font-size:16px;padding:13px 12px}
.lfga-site .lfga-optional{font-size:12px;color:#6b7180}
.lfga-site .lfga-notice{font-size:13px}
.lfga-site .lfga-privacy{font-size:12px;color:#6b7180}
.lfga-site .lfga-footer>span,.lfga-site .lfga-footer>div{font-size:13px}
.lfga-site .lfga-footer>small{font-size:12px;color:#6b7180}
.lfga-site .lfga-faq-list{border-top:1px solid #e5e6eb;max-width:860px}
.lfga-site .lfga-faq-list details{border-bottom:1px solid #e5e6eb}
.lfga-site .lfga-faq-list summary{cursor:pointer;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:20px;padding:22px 0;font:700 19px Manrope,'DM Sans',sans-serif;letter-spacing:-.02em}
.lfga-site .lfga-faq-list summary::-webkit-details-marker{display:none}
.lfga-site .lfga-faq-list summary:after{content:'+';color:var(--blue);font-size:26px;font-weight:500;transition:transform .25s}
.lfga-site .lfga-faq-list details[open] summary:after{transform:rotate(45deg)}
.lfga-site .lfga-faq-list details p{margin:0 0 24px;max-width:640px;color:#4f5562;font-size:15px;line-height:1.75}
.lfga-site .lfga-rv{opacity:0;transform:translateY(22px);transition:opacity .7s ease,transform .7s ease}
.lfga-site .lfga-rv.lfga-in{opacity:1;transform:none}
.lfga-site .lfga-project-visual{transition:transform .35s ease,box-shadow .35s ease}
.lfga-site .lfga-project-card:hover .lfga-project-visual{transform:translateY(-6px);box-shadow:0 22px 40px #2b3a8c22}
.lfga-site .lfga-project-meta>a{transition:background .2s,color .2s,border-color .2s}
.lfga-site .lfga-project-card:hover .lfga-project-meta>a{background:var(--blue);border-color:var(--blue);color:#fff}
.lfga-site .lfga-service-list article>b{display:inline-block;transition:transform .2s}
.lfga-site .lfga-service-list article:hover>b{transform:translate(3px,-3px)}
.lfga-site .lfga-button span,.lfga-site .lfga-header-cta span,.lfga-site .lfga-text-link span{transition:transform .2s}
.lfga-site .lfga-button:hover span,.lfga-site .lfga-header-cta:hover span,.lfga-site .lfga-text-link:hover span{transform:translate(2px,-2px)}
@media(max-width:600px){.lfga-site .lfga-header{height:auto;flex-wrap:wrap;padding-top:10px;padding-bottom:0;row-gap:2px}.lfga-site .lfga-nav{display:flex;order:3;width:100%;gap:22px;padding:6px 0 10px;overflow-x:auto;white-space:nowrap}.lfga-site .lfga-hero-copy>p{font-size:16px}}
@media(prefers-reduced-motion:reduce){.lfga-site *{transition:none!important;animation:none!important}}

/* ---- melhorias v3: fundo imersivo (topo escuro animado, grade, grão, brilho) ---- */
.lfga-site{position:relative;isolation:isolate}
.lfga-site::before{content:"";position:absolute;left:0;right:0;top:0;height:var(--lfga-top,720px);z-index:-2;pointer-events:none;
 background:radial-gradient(340px 340px at var(--mx,72%) var(--my,30%),rgba(156,168,236,.2),transparent 70%),radial-gradient(520px 420px at 78% 28%,rgba(43,58,140,.8),transparent 70%),radial-gradient(460px 380px at 18% 82%,rgba(122,133,191,.4),transparent 70%),radial-gradient(380px 300px at 60% 98%,rgba(43,58,140,.4),transparent 70%),linear-gradient(180deg,#07080f 0%,#0c0f1d 60%,#10142a 100%);
 background-size:100% 100%,140% 140%,140% 140%,140% 140%,100% 100%;background-repeat:no-repeat;
 animation:lfgaDrift 24s ease-in-out infinite alternate}
@keyframes lfgaDrift{from{background-position:0 0,0% 0%,100% 100%,40% 100%,0 0}to{background-position:0 0,100% 60%,0% 20%,80% 0%,0 0}}
.lfga-site::after{content:"";position:absolute;left:0;right:0;top:0;height:var(--lfga-top,720px);z-index:-1;pointer-events:none;
 background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px),url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 .09 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
 background-size:64px 64px,64px 64px,180px 180px;
 -webkit-mask-image:radial-gradient(ellipse 95% 85% at 50% 38%,#000 35%,transparent 100%);mask-image:radial-gradient(ellipse 95% 85% at 50% 38%,#000 35%,transparent 100%)}
.lfga-site .lfga-header{border-bottom-color:rgba(255,255,255,.1);transition:background .3s,border-color .3s}
.lfga-site.lfga-scrolled .lfga-header{border-bottom-color:#ececf0}
.lfga-site:not(.lfga-scrolled) .lfga-header{background:transparent!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important}
.lfga-site:not(.lfga-scrolled) .lfga-brand{color:#fff}
.lfga-site:not(.lfga-scrolled) .lfga-brand small{color:#aab0cf}
.lfga-site:not(.lfga-scrolled) .lfga-nav{color:#cfd3ea}
.lfga-site:not(.lfga-scrolled) .lfga-nav a:hover{color:#fff}
.lfga-site:not(.lfga-scrolled) .lfga-header-cta{color:#fff;border-color:rgba(255,255,255,.3)}
.lfga-site .lfga-hero h1{color:#fff}
.lfga-site .lfga-hero h1 em{color:#9ca8ec}
.lfga-site .lfga-hero .lfga-eyebrow{color:#c1c7de}
.lfga-site .lfga-hero .lfga-eyebrow>span{background:#9da8ee;box-shadow:0 0 0 4px #aab2ef1b}
.lfga-site .lfga-hero-copy>p{color:#c3c8dd}
.lfga-site .lfga-hero .lfga-text-link{color:#fff}
.lfga-site .lfga-hero-note{color:#aab0cf}
.lfga-site .lfga-hero .lfga-note-check{background:rgba(255,255,255,.12);color:#9ca8ec}
.lfga-site .lfga-hero .lfga-button-primary{background:#fff;color:var(--blue)!important}
.lfga-site .lfga-hero .lfga-button-primary:hover{background:#e7eaff}
.lfga-site .lfga-proof-strip,.lfga-site .lfga-section,.lfga-site .lfga-process,.lfga-site .lfga-footer{background-image:radial-gradient(rgba(43,58,140,.1) 1px,transparent 1px);background-size:22px 22px}
.lfga-site .lfga-services{background-image:radial-gradient(55% 70% at 100% 0%,rgba(122,133,191,.24),transparent 65%),radial-gradient(40% 55% at 0% 100%,rgba(43,58,140,.4),transparent 70%)}
.lfga-site .lfga-contact{background-image:radial-gradient(60% 80% at 92% 8%,rgba(122,133,191,.22),transparent 60%),radial-gradient(40% 60% at 0% 100%,rgba(43,58,140,.3),transparent 70%)}
@media(prefers-reduced-motion:reduce){.lfga-site::before{animation:none}}

/* ---- v5: navbar fixa que some ao descer e volta ao subir ---- */
.lfga-site{padding-top:var(--lfga-hh,84px)}
.lfga-site .lfga-header{position:fixed;top:0;left:0;right:0;margin:0;z-index:30;transition:transform .35s ease,background-color .3s,border-color .3s,box-shadow .3s;will-change:transform}
.lfga-site.lfga-hide .lfga-header{transform:translateY(-110%);box-shadow:none}
.lfga-site .lfga-header:focus-within{transform:none}
.lfga-site.lfga-scrolled .lfga-header{box-shadow:0 8px 30px rgba(10,12,30,.1)}

/* ---- v6: navbar com as mesmas cores do topo (azul-noite com brilhos) ---- */
.lfga-site.lfga-scrolled .lfga-header{background-color:#0a0c18;background-image:radial-gradient(420px 220px at 78% 0%,rgba(43,58,140,.75),transparent 70%),radial-gradient(360px 200px at 10% 100%,rgba(122,133,191,.35),transparent 70%),linear-gradient(180deg,#07080f,#0d1020);-webkit-backdrop-filter:none;backdrop-filter:none;border-bottom-color:rgba(255,255,255,.1);box-shadow:0 10px 30px rgba(5,7,18,.35)}
.lfga-site .lfga-header .lfga-brand{color:#fff}
.lfga-site .lfga-header .lfga-brand small{color:#aab0cf}
.lfga-site .lfga-header .lfga-nav{color:#cfd3ea}
.lfga-site .lfga-header .lfga-nav a:hover{color:#fff}
.lfga-site .lfga-header .lfga-header-cta{color:#fff;border-color:rgba(255,255,255,.3)}
.lfga-site .lfga-header .lfga-header-cta:hover{background:#fff;border-color:#fff;color:var(--blue)!important}

/* ---- v4: layout do notebook 3D (coluna à direita no computador, faixa embaixo no celular) ---- */
.lfga-site{--px:38px;z-index:1;background-color:transparent!important;overflow:visible!important;overflow-x:clip!important}
@media(max-width:850px){.lfga-site{--px:24px}}@media(max-width:600px){.lfga-site{--px:18px}}
@media(max-width:1099px){.lfga-site{padding-bottom:clamp(170px,30vh,260px)}}
.lfga-site .lfga-header{max-width:none;padding-left:max(var(--px),calc((100% - 1204px)/2));padding-right:max(var(--px),calc((100% - 1204px)/2))}
.lfga-site .lfga-logo-image{width:46px;height:46px;border-radius:10px}
.lfga-site .lfga-hero-slot{min-height:460px}
.lfga-site .lfga-proof-strip,.lfga-site .lfga-section,.lfga-site .lfga-process,.lfga-site .lfga-footer{max-width:none;padding-left:max(var(--px),calc((100% - 1204px)/2));padding-right:max(var(--px),calc((100% - 1204px)/2));background-color:rgba(255,255,255,.9)}
.lfga-site .lfga-services{background-color:rgba(16,18,25,.96)}
.lfga-site .lfga-about{background-color:rgba(242,243,247,.94)}
.lfga-site .lfga-contact{background-color:rgba(21,23,34,.97)}
@media(min-width:1100px){.lfga-site .lfga-proof-strip,.lfga-site .lfga-section,.lfga-site .lfga-process,.lfga-site .lfga-footer,.lfga-site .lfga-services,.lfga-site .lfga-about,.lfga-site .lfga-contact{padding-right:calc(max(var(--px),calc((100% - 1204px)/2)) + clamp(300px,27vw,420px))}}
.lfga-dock{position:fixed;left:0;right:0;bottom:0;height:clamp(170px,30vh,260px);background:linear-gradient(to top,#fff 72%,rgba(255,255,255,0));opacity:0;z-index:2;pointer-events:none}
@media(min-width:1100px){.lfga-dock{display:none}}
`
